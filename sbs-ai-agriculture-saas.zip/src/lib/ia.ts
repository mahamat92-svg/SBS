/**
 * Moteur IA SBS — guide gratuit en français très simple.
 * Réponses courtes (3-4 phrases), avec le nom exact des boutons à cliquer.
 */

export type IaContext = {
  whatsapp: string;
  proprietaire: string;
};

const base = (ctx: IaContext) =>
  `Tu peux aussi écrire au propriétaire ${ctx.proprietaire} sur WhatsApp au ${ctx.whatsapp}.`;

type Regle = { mots: RegExp; reponse: (ctx: IaContext) => string };

const REGLES: Regle[] = [
  {
    mots: /bonjour|bonsoir|salut|coucou|hello|sb[s]?/i,
    reponse: (c) =>
      `Bonjour et bienvenue chez SBS ! Je suis ton guide gratuit. Clique sur « Agriculture » ou « Élevage » en haut pour voir les outils. Tu peux aussi cliquer sur « Produits » pour acheter. ${base(c)}`,
  },
  {
    mots: /abonnement|formule|offre|business|gratuit|essai|s'inscrire|inscrire/i,
    reponse: () =>
      `Il y a 3 offres : « Gratuit » pendant 7 jours, « Pro » à 5 000 FCFA par mois et « Business » à 15 000 FCFA par mois. Clique sur le bouton « S'abonner » de l'offre que tu veux. Tu payes par Orange Money, MTN MoMo, Wave ou Carte Bancaire.`,
  },
  {
    mots: /acheter|achete|achat|commander|commande|payer|paiement|prix|combien (ça|ca) coûte/i,
    reponse: () =>
      `Pour acheter, clique sur le bouton « Produits » en haut, puis choisis ton produit et clique sur « Commander sur WhatsApp ». Ensuite tu payes par Orange Money, MTN MoMo, Wave, Carte Bancaire ou Espèces. Le paiement va directement sur le compte du propriétaire de SBS.`,
  },
  {
    mots: /whatsapp|contacter|contact|appeler|téléphone|telephone|numéro|numero/i,
    reponse: (c) =>
      `Pour parler au propriétaire, clique sur le bouton vert WhatsApp en bas à droite de l'écran. Tu peux aussi appeler le ${c.whatsapp}. ${c.proprietaire} répondra lui-même à ton message.`,
  },
  {
    mots: /météo|meteo|pluie|pleut|temps|saison|arroser aujourd/i,
    reponse: () =>
      `Pour la météo de ton champ, clique sur « Agriculture », puis sur l'outil 01 « Météo de mon champ ». Tu choisis ton village et tu vois la pluie, la chaleur et le conseil du jour. C'est gratuit, même sans abonnement.`,
  },
  {
    mots: /maladie|malade|feuille|jaune|tache|taches|insecte|ravageur|diagnostic|docteur|animal malade|vache malade/i,
    reponse: () =>
      `Pour soigner une plante ou un animal, clique sur « Agriculture » ou « Élevage », puis sur l'outil 02 « Docteur Plante » ou « Docteur Animal ». Tu décris le problème (ou tu envoies la photo) et tu reçois la maladie + le traitement. Si c'est grave, appelle un vétérinaire.`,
  },
  {
    mots: /récolte|recolte|combien de sacs|combien (je vais|je peux) gagner|rendement|bénéfice|benefice|tonnage/i,
    reponse: () =>
      `Pour connaître ta récolte, clique sur « Agriculture » puis sur l'outil 04 « Ma Récolte ». Tu entres ta surface en hectares, ta culture et ta date de semis. SBS te donne le nombre de sacs et le montant en FCFA.`,
  },
  {
    mots: /élevage|elevage|animaux|troupeau|combien (de) (vaches|chèvres|chevres|moutons|poulets)|poids|engraisser/i,
    reponse: () =>
      `Pour ton élevage, clique sur « Élevage » puis sur l'outil 04 « Mon Élevage ». Tu entres le nombre d'animaux, le poids moyen et le prix au kilo. SBS te donne la valeur totale en FCFA.`,
  },
  {
    mots: /nourrir|nourriture|aliment|pâturage|paturage|arroser|arrosage|eau/i,
    reponse: () =>
      `Pour savoir quoi faire aujourd'hui, clique sur « Élevage » puis sur l'outil 05 « Quand Nourrir ? ». Pour les plantes, clique sur « Agriculture » puis « Quand Arroser ? ». Tu reçois directement : Arrose ou N'arrose pas.`,
  },
  {
    mots: /score|note|évaluation|evaluation|niveau|améliorer|ameliorer/i,
    reponse: () =>
      `Pour avoir ta note, clique sur « Agriculture » ou « Élevage » puis sur l'outil 06 « Mon Score Agricole ». Tu réponds à 6 questions et tu reçois un score de 0 à 100 avec les points à améliorer.`,
  },
  {
    mots: /conseil|conseiller|question|comment|pourquoi|que faire|astuce/i,
    reponse: () =>
      `Pose ta question dans l'outil 03 « Conseil IA » sur la page « Agriculture » ou « Élevage ». Écris en français simple, par exemple : « Comment planter le maïs ? ». Tu reçois tout de suite une réponse claire.`,
  },
  {
    mots: /produit|boutique|magasin|vendre|vendez|sac|maïs|mais|mil|arachide|tomate|manioc|oignon|vache|chèvre|chevre|mouton|poulet|poule|œuf|oeuf/i,
    reponse: () =>
      `SBS vend du Maïs, du Mil, de l'Arachide, de la Tomate, du Manioc, de l'Oignon, et aussi des Vaches, Chèvres, Moutons, Poulets et Poules pondeuses. Clique sur le bouton « Produits » en haut pour voir les prix. Pour commander, clique sur « Commander sur WhatsApp ».`,
  },
  {
    mots: /facebook|compte|client|solde|facture|excel|tableau|devis/i,
    reponse: () =>
      `Chaque client peut recevoir sa facture avec logo et le lien Facebook du propriétaire. Pour cela, le propriétaire ouvre le « Dashboard Admin » puis le tableau Excel. Si tu es client, envoie ton nom, ton numéro et ton lien Facebook sur WhatsApp.`,
  },
  {
    mots: /connexion|connecter|inscrire|inscription|compte personnel|mot de passe/i,
    reponse: (c) =>
      `Pour créer ton compte, clique sur le bouton « S'abonner » en haut à droite, puis choisis ton offre. Tu entres ton nom, ton numéro et ton village. Ensuite tu payes et ton compte est ouvert tout de suite. ${base(c)}`,
  },
  {
    mots: /merci|super|génial|genial|parfait|bravo/i,
    reponse: (c) =>
      `Avec plaisir ! Je suis là pour toi 24h sur 24, c'est gratuit. N'hésite pas à revenir si tu as une autre question. ${base(c)}`,
  },
];

const DEFAUT = (ctx: IaContext) =>
  `Je n'ai pas bien compris, mais je peux t'aider quand même. Clique sur « Agriculture » ou « Élevage » pour les outils, ou sur « Produits » pour acheter. Tu peux aussi cliquer sur le bouton « Parler à l'IA » et reformuler ta question. ${base(ctx)}`;

export function repondreIA(question: string, ctx: IaContext): string {
  const q = (question || "").trim();
  if (q.length < 2) {
    return `Écris ta question en français simple, par exemple : « Comment acheter du maïs ? ». Je réponds tout de suite.`;
  }
  for (const regle of REGLES) {
    if (regle.mots.test(q)) return regle.reponse(ctx);
  }
  return DEFAUT(ctx);
}

/* ---------- Outils métier ---------- */

/** Météo déterministe par village (pas de service externe : fonctionne toujours). */
export function meteoVillage(nomVillage: string, date = new Date()) {
  const base = { pluieMm: 800, chaleur: 30 };
  const connues: Record<string, { pluieMm: number; chaleur: number }> = {
    "Ngaoundéré": { pluieMm: 900, chaleur: 28 },
    "Garoua": { pluieMm: 700, chaleur: 33 },
    "Maroua": { pluieMm: 600, chaleur: 35 },
    "Bafoussam": { pluieMm: 1400, chaleur: 24 },
    "Bertoua": { pluieMm: 1300, chaleur: 27 },
    "Ebolowa": { pluieMm: 1500, chaleur: 26 },
    "Kribi": { pluieMm: 1700, chaleur: 28 },
    "Nkongsamba": { pluieMm: 1600, chaleur: 25 },
    "Sarh": { pluieMm: 800, chaleur: 32 },
    "Moundou": { pluieMm: 850, chaleur: 33 },
    "N'Djamena": { pluieMm: 550, chaleur: 36 },
    "Abéché": { pluieMm: 350, chaleur: 37 },
  };
  const v = connues[nomVillage] ?? base;
  const graine = [...nomVillage].reduce((a, c) => a + c.charCodeAt(0), 0) + date.getDate() + date.getMonth() * 31;
  const rand = (n: number) => ((graine * 9301 + n * 49297) % 233280) / 233280;
  const mois = date.getMonth();
  const saisonSeche = mois >= 10 || mois <= 3;
  const pluie = saisonSeche
    ? Math.round(rand(1) * v.pluieMm / 60)
    : Math.round(2 + rand(2) * 14);
  const temperature = Math.round(v.chaleur + (saisonSeche ? 3 : -1) + rand(3) * 5);
  const humidite = Math.round((saisonSeche ? 35 : 65) + rand(4) * 25);
  const vent = Math.round(6 + rand(5) * 22);
  const conseil =
    pluie > 6
      ? "Il va pleuvoir : ne pas arroser aujourd'hui, et profiter pour semer ou fertiliser."
      : pluie > 0
        ? "Un peu de pluie prévue : arrose seulement si la terre est sèche sous la main."
        : saisonSeche
          ? "Pas de pluie : arrose tôt le matin ou tard le soir pour éviter l'évaporation."
          : "Ciel couvert sans pluie : surveille les champignons sur les feuilles.";
  return { village: nomVillage, temperature, pluie, humidite, vent, saisonSeche, conseil };
}

export function arrosageOuNon(nomVillage: string, joursDepuisArrosage: number, culture: string) {
  const m = meteoVillage(nomVillage);
  const besoins: Record<string, number> = {
    maïs: 4, mais: 4, mil: 6, arachide: 5, tomate: 2, manioc: 7, oignon: 3,
  };
  const besoin = besoins[culture.toLowerCase()] ?? 4;
  const arroser = joursDepuisArrosage >= besoin && m.pluie < 6;
  return {
    verdict: arroser ? "ARROSE AUJOURD'HUI" : "N'ARROSE PAS AUJOURD'HUI",
    explication: arroser
      ? `Cela fait ${joursDepuisArrosage} jours sans eau et il n'est pas prévu de pluie. Arrose tôt le matin.`
      : m.pluie >= 6
        ? `La pluie suffit aujourd'hui (${m.pluie} mm prévus). Attends demain.`
        : `Cela fait seulement ${joursDepuisArrosage} jour(s). Ta culture a besoin d'eau tous les ${besoin} jours.`,
    frequence: `Tous les ${besoin} jours environ`,
  };
}

export function diagnostic(type: "plante" | "animal", description: string) {
  const d = description.toLowerCase();
  const plantes = [
    {
      test: /jaune|jaun|chloros/i,
      maladie: "Carences en azote ou fer (jaunissement des feuilles)",
      traitement:
        "1) Arrose régulièrement. 2) Mets du fumier bien décomposé ou de l'urée (50 kg/ha). 3) Retire les feuilles très abîmées.",
    },
    {
      test: /tache|taches|brun|noir|rouille|champignon|mildiou/i,
      maladie: "Maladie fongique (mildiou ou rouille)",
      traitement:
        "1) Enlève les feuilles atteintes. 2) Pulvérise une bouillie bordelaise ou du savon noir + vinaigre. 3) Évite d'arroser les feuilles.",
    },
    {
      test: /insecte|puceron|chenille|trou|ver|ravageur|criquet/i,
      maladie: "Attaque d'insectes ravageurs",
      traitement:
        "1) Ramasse les insectes à la main le matin. 2) Pulvérise de l'extrait de neem ou de piment. 3) Installe des pièges jaunes.",
    },
    {
      test: /flétr|fletr|seche|sèche|fan|tombe/i,
      maladie: "Manque d'eau ou fusariose",
      traitement:
        "1) Arrose le soir. 2) Paille le sol pour garder l'eau. 3) Si le problème continue, arrache la plante malade.",
    },
  ];
  const animaux = [
    {
      test: /boiter|boit|jambe|pied/i,
      maladie: "Boiterie (blessure ou abcès du sabot)",
      traitement:
        "1) Lave la patte à l'eau tiède et au savon. 2) Applique de la teinture d'iode. 3) Isole l'animal et appelle le vétérinaire.",
    },
    {
      test: /diarrh|crotte|liquide|selles|ventre/i,
      maladie: "Diarrhée infectieuse (coccidiose ou salmonellose)",
      traitement:
        "1) Donne de l'eau propre avec du sucre et du sel. 2) Ajoute un antibiotique vétérinaire prescrit. 3) Nettoie l'enclos tous les jours.",
    },
    {
      test: /toux|nez|respir|fièvre|fievre|chaud|muqueuse/i,
      maladie: "Infection respiratoire (pasteurellose)",
      traitement:
        "1) Sépare l'animal malade. 2) Garde-le au chaud et au sec. 3) Injecte un antibiotique prescrit par le vétérinaire sous 24 h.",
    },
    {
      test: /peau|gale|gratt|perte de poil|tique/i,
      maladie: "Gale ou infestation de tiques",
      traitement:
        "1) Lave l'animal avec un acaricide (deltaméthrine). 2) Traite tout le troupeau. 3) Désinfecte l'enclos et la litière.",
    },
  ];
  const liste = type === "plante" ? plantes : animaux;
  const trouve = liste.find((x) => x.test.test(d));
  if (trouve) return trouve;
  return {
    maladie:
      type === "plante"
        ? "Stress hydrique ou faiblesse générale"
        : "Fatigue générale ou parasitose",
    traitement:
      type === "plante"
        ? "1) Vérifie l'eau : la terre doit être humide mais pas détrempée. 2) Ajoute du fumier. 3) Observe 3 jours, si ça empire envoie une photo plus nette."
        : "1) Donne de l'eau propre et une nourriture de bonne qualité. 2) Observe la température et l'appétit. 3) Si ça empire dans les 24 h, appelle le vétérinaire.",
  };
}

export function scoreAgricole(rep: {
  surface: number;
  irrigation: boolean;
  fumure: boolean;
  analyseSol: boolean;
  protection: boolean;
  diversification: boolean;
}) {
  let score = 20;
  if (rep.surface >= 1) score += 15;
  else score += Math.round(rep.surface * 15);
  if (rep.irrigation) score += 15;
  if (rep.fumure) score += 15;
  if (rep.analyseSol) score += 12;
  if (rep.protection) score += 13;
  if (rep.diversification) score += 10;
  score = Math.max(0, Math.min(100, Math.round(score)));
  const niveau =
    score >= 80 ? "Excellente exploitation" : score >= 60 ? "Bonne exploitation" : score >= 40 ? "Exploitation à améliorer" : "Exploitation fragile";
  const conseils: string[] = [];
  if (!rep.fumure) conseils.push("Ajoute du fumier ou du compost : +15 points.");
  if (!rep.irrigation) conseils.push("Installe un point d'eau ou un goutte-à-goutte : +15 points.");
  if (!rep.analyseSol) conseils.push("Fais analyser ton sol une fois par an : +12 points.");
  if (!rep.protection) conseils.push("Protège tes cultures (filets, traitements doux) : +13 points.");
  if (!rep.diversification) conseils.push("Cultive 2 espèces au moins pour réduire les risques : +10 points.");
  if (conseils.length === 0) conseils.push("Continue comme ça, ton exploitation est bien tenue.");
  return { score, niveau, conseils };
}
