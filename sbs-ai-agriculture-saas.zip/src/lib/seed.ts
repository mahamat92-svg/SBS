import { db } from "@/db";
import { sbsProduits, sbsSettings } from "@/db/schema";
import { eq } from "drizzle-orm";

const PRODUITS_DEFAUT = [
  { nom: "Maïs", categorie: "Agriculture", unite: "sac de 100 kg", prixUnitaire: 12000, quantite: 120, description: "Maïs jaune séché au soleil, trié à la main, récolte Ngaoundéré.", ordre: 1 },
  { nom: "Mil", categorie: "Agriculture", unite: "sac de 100 kg", prixUnitaire: 15000, quantite: 80, description: "Mil perlé de saison, idéal pour la bouillie et le couscous.", ordre: 2 },
  { nom: "Arachide", categorie: "Agriculture", unite: "sac de 100 kg", prixUnitaire: 30000, quantite: 60, description: "Arachide décortiquée, graines sélectionnées pour l'huile.", ordre: 3 },
  { nom: "Tomate", categorie: "Agriculture", unite: "caisse de 50 kg", prixUnitaire: 20000, quantite: 45, description: "Tomates fraîches cueillies le matin, livraison sous 24 h.", ordre: 4 },
  { nom: "Manioc", categorie: "Agriculture", unite: "sac de 100 kg", prixUnitaire: 10000, quantite: 90, description: "Tubercules de manioc frais, pour le cossettes ou la farine.", ordre: 5 },
  { nom: "Oignon", categorie: "Agriculture", unite: "sac de 50 kg", prixUnitaire: 25000, quantite: 70, description: "Oignon rouge sec, conservation longue, très demandé en saison sèche.", ordre: 6 },
  { nom: "Vaches", categorie: "Élevage", unite: "tête", prixUnitaire: 750000, quantite: 12, description: "Zebu de 250 kg environ, bien gras, vacciné et vermifugé.", ordre: 7 },
  { nom: "Chèvres", categorie: "Élevage", unite: "tête", prixUnitaire: 87500, quantite: 30, description: "Chèvres locales de 25 kg, élevées en plein air.", ordre: 8 },
  { nom: "Moutons", categorie: "Élevage", unite: "tête", prixUnitaire: 105000, quantite: 25, description: "Moutons de 30 kg, prêts pour les fêtes.", ordre: 9 },
  { nom: "Poulets", categorie: "Élevage", unite: "pièce", prixUnitaire: 5000, quantite: 150, description: "Poulets de chair de 60 jours, nourris au maïs.", ordre: 10 },
  { nom: "Poules pondeuses", categorie: "Élevage", unite: "pièce", prixUnitaire: 8000, quantite: 60, description: "Pondeuses en ponte, jusqu'à 280 œufs par an.", ordre: 11 },
];

let promesse: Promise<void> | null = null;

/** Garantit l'existence des réglages du propriétaire et du catalogue. */
export function initialiser(): Promise<void> {
  if (!promesse) {
    promesse = (async () => {
      try {
        const reglages = await db
          .select()
          .from(sbsSettings)
          .where(eq(sbsSettings.id, "principal"))
          .limit(1);
        if (reglages.length === 0) {
          await db.insert(sbsSettings).values({ id: "principal" }).onConflictDoNothing();
        }
        const produits = await db.select().from(sbsProduits).limit(1);
        if (produits.length === 0) {
          await db.insert(sbsProduits).values(PRODUITS_DEFAUT);
        }
      } catch (e) {
        console.error("SBS: initialisation base", e);
      }
    })();
  }
  return promesse;
}

export async function lireReglages() {
  await initialiser();
  const rows = await db
    .select()
    .from(sbsSettings)
    .where(eq(sbsSettings.id, "principal"))
    .limit(1);
  return rows[0];
}
