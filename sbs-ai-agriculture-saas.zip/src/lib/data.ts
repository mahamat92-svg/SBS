/** Données métier SBS — Agriculture & Élevage (Cameroun / Tchad) */

export type Culture = {
  id: string;
  nom: string;
  image: string;
  rendementSacsHa: number;
  prixSac: number;
  sacKg: number;
  cycleJours: number;
  arrosageJours: number;
  semis: string;
  note: string;
};

export const CULTURES: Culture[] = [
  {
    id: "mais",
    nom: "Maïs",
    image: "🌽",
    rendementSacsHa: 18,
    prixSac: 12000,
    sacKg: 100,
    cycleJours: 110,
    arrosageJours: 4,
    semis: "Mai – Juin",
    note: "Le maïs aime la chaleur. Semis dès les 3 premières pluies.",
  },
  {
    id: "mil",
    nom: "Mil",
    image: "🌾",
    rendementSacsHa: 12,
    prixSac: 15000,
    sacKg: 100,
    cycleJours: 120,
    arrosageJours: 6,
    semis: "Juin – Juillet",
    note: "Le mil résiste à la sécheresse. Idéal pour les sols sableux.",
  },
  {
    id: "arachide",
    nom: "Arachide",
    image: "🥜",
    rendementSacsHa: 14,
    prixSac: 30000,
    sacKg: 100,
    cycleJours: 100,
    arrosageJours: 5,
    semis: "Juin – Juillet",
    note: "L'arachide enrichit le sol. Bonne culture après le maïs.",
  },
  {
    id: "tomate",
    nom: "Tomate",
    image: "🍅",
    rendementSacsHa: 22,
    prixSac: 20000,
    sacKg: 50,
    cycleJours: 90,
    arrosageJours: 2,
    semis: "Octobre – Novembre",
    note: "La tomate demande de l'eau régulière et un bon paillage.",
  },
  {
    id: "manioc",
    nom: "Manioc",
    image: "🍠",
    rendementSacsHa: 25,
    prixSac: 10000,
    sacKg: 100,
    cycleJours: 240,
    arrosageJours: 7,
    semis: "Avril – Mai",
    note: "Le manioc craint peu la sécheresse. Récolte à 8 mois.",
  },
  {
    id: "oignon",
    nom: "Oignon",
    image: "🧅",
    rendementSacsHa: 20,
    prixSac: 25000,
    sacKg: 50,
    cycleJours: 110,
    arrosageJours: 3,
    semis: "Novembre – Décembre",
    note: "L'oignon se vend très bien en saison sèche.",
  },
];

export type Animal = {
  id: string;
  nom: string;
  image: string;
  poidsKg: number;
  prixKg: number;
  gainJourKg: number;
  joursGras: number;
  nourritureJours: number;
  porteeAn: number;
  note: string;
};

export const ANIMAUX: Animal[] = [
  {
    id: "vaches",
    nom: "Vaches",
    image: "🐄",
    poidsKg: 250,
    prixKg: 3000,
    gainJourKg: 0.7,
    joursGras: 180,
    nourritureJours: 1,
    porteeAn: 1,
    note: "Une vache bien nourrie prend 0,7 kg par jour engraissé.",
  },
  {
    id: "chevres",
    nom: "Chèvres",
    image: "🐐",
    poidsKg: 25,
    prixKg: 3500,
    gainJourKg: 0.12,
    joursGras: 120,
    nourritureJours: 1,
    porteeAn: 2,
    note: "La chèvre se reproduit vite : 2 portées par an, 2 petits.",
  },
  {
    id: "moutons",
    nom: "Moutons",
    image: "🐑",
    poidsKg: 30,
    prixKg: 3500,
    gainJourKg: 0.15,
    joursGras: 130,
    nourritureJours: 1,
    porteeAn: 1,
    note: "Le mouton de Tabaski se vend très cher entre juin et août.",
  },
  {
    id: "poulets",
    nom: "Poulets",
    image: "🍗",
    poidsKg: 2,
    prixKg: 2500,
    gainJourKg: 0.05,
    joursGras: 60,
    nourritureJours: 2,
    porteeAn: 3,
    note: "Poulet de chair vendu à 60 jours. Prévoir 2 repas par jour.",
  },
  {
    id: "pondeuses",
    nom: "Poules pondeuses",
    image: "🥚",
    poidsKg: 1.8,
    prixKg: 3000,
    gainJourKg: 0.03,
    joursGras: 150,
    nourritureJours: 2,
    porteeAn: 280,
    note: "Une pondeuse donne 280 œufs par an, soit 150 FCFA l'œuf.",
  },
];

export type Village = {
  nom: string;
  region: string;
  pays: string;
  pluieMm: number;
  chaleur: number;
};

export const VILLAGES: Village[] = [
  { nom: "Ngaoundéré", region: "Adamaoua", pays: "Cameroun", pluieMm: 900, chaleur: 28 },
  { nom: "Garoua", region: "Nord", pays: "Cameroun", pluieMm: 700, chaleur: 33 },
  { nom: "Maroua", region: "Extrême-Nord", pays: "Cameroun", pluieMm: 600, chaleur: 35 },
  { nom: "Bafoussam", region: "Ouest", pays: "Cameroun", pluieMm: 1400, chaleur: 24 },
  { nom: "Bertoua", region: "Est", pays: "Cameroun", pluieMm: 1300, chaleur: 27 },
  { nom: "Ebolowa", region: "Sud", pays: "Cameroun", pluieMm: 1500, chaleur: 26 },
  { nom: "Kribi", region: "Littoral", pays: "Cameroun", pluieMm: 1700, chaleur: 28 },
  { nom: "Nkongsamba", region: "Littoral", pays: "Cameroun", pluieMm: 1600, chaleur: 25 },
  { nom: "Sarh", region: "Moyen-Chari", pays: "Tchad", pluieMm: 800, chaleur: 32 },
  { nom: "Moundou", region: "Logone", pays: "Tchad", pluieMm: 850, chaleur: 33 },
  { nom: "N'Djamena", region: "Ville", pays: "Tchad", pluieMm: 550, chaleur: 36 },
  { nom: "Abéché", region: "Ouadaï", pays: "Tchad", pluieMm: 350, chaleur: 37 },
];

export const METHODES_PAIEMENT = [
  "Orange Money",
  "MTN MoMo",
  "Wave",
  "Carte Bancaire",
  "Espèces",
] as const;

export const OFFRES = [
  {
    id: "gratuit",
    nom: "Gratuit",
    prix: 0,
    periode: "7 jours d'essai",
    couleur: "vert",
    inclus: [
      "Les 6 outils IA en version découverte",
      "Météo de votre village",
      "Guide IA gratuite à vie",
      "Voir tous les produits SBS",
    ],
  },
  {
    id: "pro",
    nom: "Pro",
    prix: 5000,
    periode: "par mois",
    couleur: "bleu",
    inclus: [
      "Les 6 outils IA sans limite",
      "Docteur Plante & Docteur Animal",
      "Calcul de récolte et de troupeau",
      "Score agricole mensuel",
      "Tableau Excel + Export PDF",
      "Appel WhatsApp prioritaire",
    ],
  },
  {
    id: "business",
    nom: "Business",
    prix: 15000,
    periode: "par mois",
    couleur: "ocre",
    inclus: [
      "Tout le pack Pro",
      "Gestion de plusieurs champs",
      "Factures illimitées avec votre logo",
      "Suivi des clients + lien Facebook",
      "Visite technique 1 fois par mois",
      "Accès direct au propriétaire",
    ],
  },
];

export const fcfa = (n: number) =>
  new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 0 }).format(Math.round(n)) + " FCFA";

export const nombre = (n: number) =>
  new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 1 }).format(n);
