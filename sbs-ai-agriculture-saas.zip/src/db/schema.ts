import {
  boolean,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

/**
 * SBS — Héritage Agricole et Naturel
 * Schéma PostgreSQL (compatible Supabase). Tables prefixées `sbs_`.
 */

/** Réglages du propriétaire (table singleton) */
export const sbsSettings = pgTable("sbs_settings", {
  id: text("id").primaryKey(),
  nom: text("nom").notNull().default("SBS — Héritage Agricole et Naturel"),
  slogan: text("slogan")
    .notNull()
    .default("Héritage Agricole et Naturel"),
  proprietaire: text("proprietaire").notNull().default("M. Abakar Ngarnia"),
  logoUrl: text("logo_url").notNull().default("/images/logo-sbs.svg"),
  whatsapp: text("whatsapp").notNull().default("+235 66 00 00 00"),
  email: text("email").notNull().default("contact@sbs-agriculture.cm"),
  ville: text("ville").notNull().default("Ngaoundéré"),
  pays: text("pays").notNull().default("Cameroun"),
  orangeMoney: text("orange_money").notNull().default("+235 __ __ __ __"),
  mtnMomo: text("mtn_momo").notNull().default("+235 __ __ __ __"),
  wave: text("wave").notNull().default("+235 __ __ __ __"),
  carteBancaire: text("carte_bancaire").notNull().default("Visa / Mastercard **** ____"),
  nomBanque: text("nom_banque").notNull().default("Afriland First Bank"),
  soldeMobileMoney: integer("solde_mobile_money").notNull().default(0),
  soldeCarteBancaire: integer("solde_carte_bancaire").notNull().default(0),
  soldeEspeces: integer("solde_especes").notNull().default(0),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

/** Conversations de l'IA guide gratuite */
export const sbsIaConversations = pgTable("sbs_ia_conversations", {
  id: serial("id").primaryKey(),
  question: text("question").notNull(),
  reponse: text("reponse").notNull(),
  date: timestamp("date", { withTimezone: true }).defaultNow().notNull(),
});

/** Clients du propriétaire */
export const sbsClients = pgTable("sbs_clients", {
  id: serial("id").primaryKey(),
  nom: text("nom").notNull(),
  telephone: text("telephone").notNull().default(""),
  village: text("village").notNull().default(""),
  service: text("service").notNull().default("Agriculture"),
  lienFacebook: text("lien_facebook").notNull().default(""),
  offre: text("offre").notNull().default("Gratuit 7 jours"),
  soldeMobileMoney: integer("solde_mobile_money").notNull().default(0),
  soldeCarteBancaire: integer("solde_carte_bancaire").notNull().default(0),
  date: timestamp("date", { withTimezone: true }).defaultNow().notNull(),
});

/** Produits / récoltes / animaux vendus par le propriétaire */
export const sbsProduits = pgTable("sbs_produits", {
  id: serial("id").primaryKey(),
  nom: text("nom").notNull(),
  categorie: text("categorie").notNull().default("Agriculture"),
  unite: text("unite").notNull().default("sac de 100 kg"),
  prixUnitaire: integer("prix_unitaire").notNull().default(0),
  quantite: integer("quantite").notNull().default(0),
  disponible: boolean("disponible").notNull().default(true),
  description: text("description").notNull().default(""),
  ordre: integer("ordre").notNull().default(0),
});

/** Factures / devis du tableau Excel */
export const sbsFactures = pgTable("sbs_factures", {
  id: serial("id").primaryKey(),
  reference: text("reference").notNull(),
  clientNom: text("client_nom").notNull().default("Client comptoir"),
  lignes: jsonb("lignes").notNull().default([]),
  sousTotal: integer("sous_total").notNull().default(0),
  remise: integer("remise").notNull().default(0),
  tva: integer("tva").notNull().default(0),
  total: integer("total").notNull().default(0),
  statut: text("statut").notNull().default("En attente"),
  date: timestamp("date", { withTimezone: true }).defaultNow().notNull(),
});

/** Paiements d'abonnement — crédité sur les comptes DU PROPRIÉTAIRE */
export const sbsPaiements = pgTable("sbs_paiements", {
  id: serial("id").primaryKey(),
  clientNom: text("client_nom").notNull().default(""),
  telephone: text("telephone").notNull().default(""),
  offre: text("offre").notNull().default("Pro"),
  montant: integer("montant").notNull().default(0),
  methode: text("methode").notNull().default("Orange Money"),
  reference: text("reference").notNull().default(""),
  statut: text("statut").notNull().default("Payé"),
  date: timestamp("date", { withTimezone: true }).defaultNow().notNull(),
});

export type SbsSettings = typeof sbsSettings.$inferSelect;
export type SbsClient = typeof sbsClients.$inferSelect;
export type SbsProduit = typeof sbsProduits.$inferSelect;
export type SbsFacture = typeof sbsFactures.$inferSelect;
export type SbsPaiement = typeof sbsPaiements.$inferSelect;
export type SbsIaConversation = typeof sbsIaConversations.$inferSelect;
