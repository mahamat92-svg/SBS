/**
 * Logo SBS — Héritage Agricole et Naturel.
 * Médaillon vectoriel dessiné à la main : anneau double, ruban circulaire,
 * arbre à racines, épi de maïs, zébu, mangue, engrenage.
 * Fonctionne en aplat monochrome et reste lisible à 16 px.
 */
export function LogoEmblem({
  className = "h-16 w-16",
  mono = false,
  id = "sbs",
}: {
  className?: string;
  mono?: boolean;
  id?: string;
}) {
  const vert = mono ? "currentColor" : "#166534";
  const vertClair = mono ? "currentColor" : "#1d8a4b";
  const terre = mono ? "currentColor" : "#8a5a2b";
  const mangue = mono ? "currentColor" : "#e8a33d";
  const feuille = mono ? "currentColor" : "#1d8a4b";
  const ciel = mono ? "none" : "#f4f8f2";

  return (
    <svg
      viewBox="0 0 240 240"
      className={className}
      role="img"
      aria-label="Logo SBS — Héritage Agricole et Naturel"
    >
      <defs>
        <path id={`${id}-arc-texte`} d="M 120,120 m -96,0 a 96,96 0 1,1 192,0 a 96,96 0 1,1 -192,0" />
        <clipPath id={`${id}-clip`}>
          <circle cx="120" cy="120" r="88" />
        </clipPath>
        <radialGradient id={`${id}-ciel`} cx="50%" cy="35%" r="70%">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="100%" stopColor={ciel} />
        </radialGradient>
      </defs>

      {/* Anneaux */}
      <circle cx="120" cy="120" r="118" fill="none" stroke={vert} strokeWidth="5" />
      <circle cx="120" cy="120" r="108" fill="none" stroke={vert} strokeWidth="2" />

      {/* Ruban circulaire */}
      <circle cx="120" cy="120" r="99" fill={vert} />
      <text
        fill={mono ? "#fff" : "#f4f8f2"}
        fontFamily="var(--font-display), Georgia, serif"
        fontSize="15"
        fontWeight="700"
        letterSpacing="4.2"
      >
        <textPath href={`#${id}-arc-texte`} startOffset="50%" textAnchor="middle">
          HÉRITAGE AGRICOLE ET NATUREL
        </textPath>
      </text>

      {/* Scène intérieure */}
      <g clipPath={`url(#${id}-clip)`}>
        <circle cx="120" cy="120" r="88" fill={`url(#${id}-ciel)`} />

        {/* Soleil */}
        <circle cx="176" cy="52" r="17" fill={mono ? "currentColor" : "#f6c453"} opacity={mono ? 0.25 : 1} />

        {/* Collines */}
        <path d="M 22,168 C 60,142 92,158 120,150 C 154,140 190,152 218,140 L 218,214 L 22,214 Z" fill={mono ? "currentColor" : "#7cc07f"} opacity={mono ? 0.25 : 1} />
        <path d="M 22,182 C 58,168 96,182 126,174 C 160,165 194,178 218,170 L 218,214 L 22,214 Z" fill={mono ? "currentColor" : "#4e9c5c"} opacity={mono ? 0.35 : 1} />

        {/* Souches / sillons */}
        <g stroke={terre} strokeWidth="2.4" fill="none" strokeLinecap="round" opacity="0.85">
          <path d="M 60,196 C 84,190 112,192 138,198" />
          <path d="M 70,204 C 96,198 126,200 152,206" />
        </g>

        {/* Arbre : houppier */}
        <g>
          <circle cx="120" cy="72" r="30" fill={mono ? "currentColor" : "#1d8a4b"} />
          <circle cx="98" cy="82" r="21" fill={mono ? "currentColor" : "#2f9e5c"} />
          <circle cx="143" cy="83" r="21" fill={mono ? "currentColor" : "#2f9e5c"} />
          <circle cx="120" cy="58" r="19" fill={mono ? "currentColor" : "#43b06d"} />
          <circle cx="107" cy="66" r="14" fill={mono ? "currentColor" : "#57bd7c"} opacity="0.9" />
        </g>

        {/* Tronc */}
        <path
          d="M 114,100 C 113,118 112,132 111,146 L 129,146 C 128,132 127,118 126,100 Z"
          fill={terre}
        />
        <path d="M 118,104 L 117,144" stroke={mono ? "currentColor" : "#6d4522"} strokeWidth="1.6" opacity="0.6" />

        {/* Racines */}
        <g stroke={terre} strokeWidth="4.2" fill="none" strokeLinecap="round">
          <path d="M 113,146 C 104,158 92,164 74,172" />
          <path d="M 116,147 C 111,162 104,172 92,182" />
          <path d="M 120,148 C 120,164 120,176 120,190" />
          <path d="M 124,147 C 129,162 136,172 148,182" />
          <path d="M 127,146 C 136,158 148,164 166,172" />
        </g>
        <g stroke={terre} strokeWidth="2.2" fill="none" strokeLinecap="round" opacity="0.8">
          <path d="M 96,168 C 88,172 82,178 78,186" />
          <path d="M 144,168 C 152,172 158,178 162,186" />
          <path d="M 120,172 C 112,180 108,188 106,194" />
          <path d="M 120,172 C 128,180 132,188 134,194" />
        </g>

        {/* Épi de maïs / blé à gauche */}
        <g transform="translate(56,86) rotate(-12)">
          <path d="M 12,58 C 12,38 12,20 12,2" stroke={mono ? "currentColor" : "#c9932c"} strokeWidth="3" fill="none" strokeLinecap="round" />
          {[0, 1, 2, 3, 4].map((i) => (
            <g key={i}>
              <ellipse cx="4" cy={12 + i * 11} rx="8" ry="5" fill={mangue} transform={`rotate(-24 4 ${12 + i * 11})`} />
              <ellipse cx="20" cy={17 + i * 11} rx="8" ry="5" fill={mangue} transform={`rotate(24 20 ${17 + i * 11})`} />
            </g>
          ))}
          <path d="M 12,2 C 8,-4 4,-8 0,-10" stroke={mono ? "currentColor" : "#c9932c"} strokeWidth="2.4" fill="none" strokeLinecap="round" />
        </g>

        {/* Zébu à droite */}
        <g transform="translate(146,66)">
          <path
            d="M 8,44 C 2,36 2,24 8,16 C 12,10 20,6 27,8 C 34,10 38,18 37,26 C 36,34 30,42 22,46 Z"
            fill={mono ? "currentColor" : "#a9682f"}
          />
          {/* Oreille */}
          <path d="M 30,14 C 38,10 44,12 46,18 C 42,20 36,20 31,19 Z" fill={mono ? "currentColor" : "#c07d3c"} />
          {/* Cornes */}
          <path d="M 14,10 C 8,2 2,-2 -6,-4" stroke={mono ? "currentColor" : "#e6d3ae"} strokeWidth="4" fill="none" strokeLinecap="round" />
          <path d="M 28,8 C 32,-1 38,-6 46,-8" stroke={mono ? "currentColor" : "#e6d3ae"} strokeWidth="4" fill="none" strokeLinecap="round" />
          {/* Œil + museau */}
          <circle cx="18" cy="22" r="2.6" fill={mono ? "#fff" : "#2c1a0c"} />
          <ellipse cx="12" cy="38" rx="7" ry="5" fill={mono ? "currentColor" : "#7d4a20"} />
        </g>

        {/* Mangue */}
        <g transform="translate(158,128)">
          <path d="M 16,6 C 28,6 36,16 36,28 C 36,40 28,50 16,50 C 6,50 0,42 0,32 C 0,18 6,6 16,6 Z" fill={mangue} />
          <path d="M 16,6 C 22,6 28,12 30,20 C 26,12 20,8 14,8 Z" fill={mono ? "currentColor" : "#f3c169"} />
          <path d="M 18,4 C 22,-4 30,-8 38,-8 C 36,0 30,5 22,6 Z" fill={feuille} />
        </g>

        {/* Engrenage */}
        <g transform="translate(52,146)">
          <circle cx="14" cy="14" r="12" fill={mono ? "currentColor" : "#8a5a2b"} />
          <circle cx="14" cy="14" r="5" fill={mono ? "#fff" : "#f4f8f2"} />
          {[0, 45, 90, 135, 180, 225, 270, 315].map((a) => (
            <rect
              key={a}
              x="11"
              y="-3"
              width="6"
              height="8"
              rx="2"
              fill={mono ? "currentColor" : "#8a5a2b"}
              transform={`rotate(${a} 14 14)`}
            />
          ))}
        </g>
      </g>

      {/* Monogramme SBS */}
      <text
        x="120"
        y="128"
        textAnchor="middle"
        fontFamily="var(--font-display), Georgia, serif"
        fontSize="52"
        fontWeight="900"
        letterSpacing="1"
        fill={vert}
        stroke={mono ? "none" : "#ffffff"}
        strokeWidth={mono ? 0 : 7}
        paintOrder="stroke"
      >
        SBS
      </text>
    </svg>
  );
}

export function Logo({
  className = "h-12 w-auto",
  compact = false,
}: {
  className?: string;
  compact?: boolean;
}) {
  return (
    <span className="inline-flex items-center gap-3">
      <LogoEmblem className={className} />
      {!compact && (
        <span className="leading-none">
          <span className="block font-display text-2xl font-black tracking-tight text-foret">SBS</span>
          <span className="label-marche block text-[0.58rem] text-encre/60">
            Héritage Agricole & Naturel
          </span>
        </span>
      )}
    </span>
  );
}
