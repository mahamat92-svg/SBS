"use client";

import Link from "next/link";
import { useState } from "react";
import { Menu, X, MessageCircle, Sparkles } from "lucide-react";
import { LogoEmblem } from "./Logo";

const LIENS = [
  { href: "/", label: "Accueil" },
  { href: "/agriculture", label: "Agriculture" },
  { href: "/elevage", label: "Élevage" },
  { href: "/produits", label: "Produits" },
  { href: "/contact", label: "Contact" },
];

export default function Nav({ nom, whatsapp }: { nom: string; whatsapp: string }) {
  const [ouvert, setOuvert] = useState(false);
  const numero = whatsapp.replace(/[^\d]/g, "");

  return (
    <header className="sticky top-0 z-40 border-b border-terre/80 bg-papier/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6 lg:px-8">
        <Link href="/" className="group flex items-center gap-3" aria-label={nom}>
          <LogoEmblem className="h-11 w-11 shrink-0 transition-transform duration-500 group-hover:rotate-6" />
          <span className="leading-tight">
            <span className="block font-display text-xl font-black tracking-tight text-foret">SBS</span>
            <span className="label-marche block text-[0.55rem] text-encre/55">Héritage Agricole</span>
          </span>
        </Link>

        <nav className="hidden items-center gap-7 lg:flex">
          {LIENS.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className="lien-souligne text-[0.92rem] font-medium text-encre/80 transition-colors hover:text-foret"
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Link
            href="/admin"
            className="hidden items-center gap-2 rounded-full border border-terre px-4 py-2 text-sm font-semibold text-encre/75 transition-colors hover:border-foret hover:text-foret sm:inline-flex"
          >
            <Sparkles className="h-4 w-4" />
            Dashboard Admin
          </Link>
          <Link
            href="/#offres"
            className="hidden rounded-full bg-foret px-5 py-2.5 text-sm font-semibold text-white shadow-[0_10px_25px_-12px_rgba(22,101,52,0.9)] transition-transform hover:-translate-y-0.5 sm:inline-flex"
          >
            S&apos;abonner
          </Link>
          <a
            href={`https://wa.me/${numero}`}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 rounded-full bg-[#25D366] px-4 py-2.5 text-sm font-semibold text-[#07321b] transition-transform hover:-translate-y-0.5"
          >
            <MessageCircle className="h-4 w-4" />
            <span className="hidden md:inline">WhatsApp</span>
          </a>
          <button
            type="button"
            onClick={() => setOuvert((v) => !v)}
            className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-terre text-foret lg:hidden"
            aria-label={ouvert ? "Fermer le menu" : "Ouvrir le menu"}
          >
            {ouvert ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {ouvert && (
        <nav className="border-t border-terre bg-white px-4 pb-5 pt-3 lg:hidden">
          <ul className="space-y-1">
            {LIENS.map((l) => (
              <li key={l.href}>
                <Link
                  href={l.href}
                  onClick={() => setOuvert(false)}
                  className="block rounded-xl px-4 py-3 text-base font-medium text-encre hover:bg-voile"
                >
                  {l.label}
                </Link>
              </li>
            ))}
            <li>
              <Link
                href="/admin"
                onClick={() => setOuvert(false)}
                className="block rounded-xl px-4 py-3 text-base font-medium text-foret hover:bg-voile"
              >
                Dashboard Admin
              </Link>
            </li>
            <li>
              <Link
                href="/#offres"
                onClick={() => setOuvert(false)}
                className="mt-2 block rounded-xl bg-foret px-4 py-3 text-center text-base font-semibold text-white"
              >
                S&apos;abonner — à partir de 0 FCFA
              </Link>
            </li>
          </ul>
        </nav>
      )}
    </header>
  );
}
