"use client";

import { useMemo, useState } from "react";
import { Download, FileUp, Plus, Printer, Save, Trash2, Loader2 } from "lucide-react";
import LogoProprietaire from "./LogoProprietaire";
import { fcfa } from "@/lib/data";

export type Ligne = { id: number; produit: string; quantite: number; prixUnitaire: number };

const colonne = "px-4 py-3 text-left align-middle";

export default function TableauExcel({
  proprietaire = "SBS — Héritage Agricole et Naturel",
  whatsapp = "+235 66 00 00 00",
  ville = "Ngaoundéré",
  logoUrl,
}: {
  proprietaire?: string;
  whatsapp?: string;
  ville?: string;
  logoUrl?: string;
}) {
  const [lignes, setLignes] = useState<Ligne[]>([
    { id: 1, produit: "Maïs — sac de 100 kg", quantite: 12, prixUnitaire: 12000 },
    { id: 2, produit: "Arachide — sac de 100 kg", quantite: 4, prixUnitaire: 30000 },
    { id: 3, produit: "Chèvres — tête", quantite: 2, prixUnitaire: 87500 },
  ]);
  const [clientNom, setClientNom] = useState("Moussa Ibrahim");
  const [remise, setRemise] = useState(0);
  const [tauxTva, setTauxTva] = useState(19.25);
  const [message, setMessage] = useState<string | null>(null);
  const [sauvegarde, setSauvegarde] = useState(false);

  const sousTotal = useMemo(
    () => lignes.reduce((s, l) => s + l.quantite * l.prixUnitaire, 0),
    [lignes],
  );
  const remiseMontant = Math.min(remise, sousTotal);
  const base = Math.max(0, sousTotal - remiseMontant);
  const tva = Math.round((base * tauxTva) / 100);
  const total = base + tva;

  function majLigne(id: number, champ: Partial<Ligne>) {
    setLignes((ls) => ls.map((l) => (l.id === id ? { ...l, ...champ } : l)));
  }

  function ajouterLigne() {
    setLignes((ls) => [
      ...ls,
      { id: (ls[ls.length - 1]?.id ?? 0) + 1, produit: "", quantite: 1, prixUnitaire: 0 },
    ]);
  }

  function exporterExcel() {
    const entetes = ["Produit", "Quantité", "Prix Unitaire FCFA", "Total FCFA"];
    const corps = lignes
      .map(
        (l) =>
          `<tr><td>${l.produit}</td><td>${l.quantite}</td><td>${l.prixUnitaire}</td><td>${
            l.quantite * l.prixUnitaire
          }</td></tr>`,
      )
      .join("");
    const html = `<html xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="utf-8"></head><body>
      <h2>${proprietaire} — Facture</h2><p>Client : ${clientNom}</p>
      <table border="1"><thead><tr>${entetes.map((h) => `<th>${h}</th>`).join("")}</tr></thead>
      <tbody>${corps}
      <tr><td colspan="3"><b>Sous-Total</b></td><td><b>${sousTotal}</b></td></tr>
      <tr><td colspan="3">Remise</td><td>${remiseMontant}</td></tr>
      <tr><td colspan="3">TVA (${tauxTva}%)</td><td>${tva}</td></tr>
      <tr><td colspan="3"><b>TOTAL À PAYER</b></td><td><b>${total}</b></td></tr>
      </tbody></table></body></html>`;
    const blob = new Blob([html], { type: "application/vnd.ms-excel;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `facture-sbs-${clientNom.replace(/\s+/g, "-").toLowerCase() || "client"}.xls`;
    a.click();
    URL.revokeObjectURL(url);
    setMessage("Fichier Excel téléchargé.");
  }

  function importerExcel(fichier: File) {
    const lecteur = new FileReader();
    lecteur.onload = () => {
      const texte = String(lecteur.result ?? "");
      const lignesTexte = texte.split(/\r?\n/).filter((l) => l.trim().length > 0);
      const nouvelles: Ligne[] = [];
      lignesTexte.forEach((ligne, i) => {
        const cellules = ligne.split(/[;,\t]/).map((c) => c.trim().replace(/^"|"$/g, ""));
        if (cellules.length < 3) return;
        const qte = Number(cellules[1]);
        const prix = Number(cellules[2]);
        if (!Number.isFinite(qte) || !Number.isFinite(prix)) return;
        nouvelles.push({
          id: (nouvelles[nouvelles.length - 1]?.id ?? 0) + 1,
          produit: cellules[0],
          quantite: qte,
          prixUnitaire: prix,
        });
        void i;
      });
      if (nouvelles.length > 0) {
        setLignes(nouvelles);
        setMessage(`${nouvelles.length} ligne(s) importée(s).`);
      } else {
        setMessage("Aucune ligne valide trouvée dans ce fichier.");
      }
    };
    lecteur.readAsText(fichier);
  }

  async function enregistrer() {
    setSauvegarde(true);
    setMessage(null);
    try {
      const rep = await fetch("/api/invoices", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ clientNom, lignes, remise: remiseMontant, tauxTva }),
      });
      const d = (await rep.json()) as { reference?: string; erreur?: string };
      setMessage(
        d.erreur ? d.erreur : `Facture ${d.reference} enregistrée — TOTAL ${fcfa(total)}.`,
      );
    } catch {
      setMessage("Enregistrement impossible pour le moment.");
    } finally {
      setSauvegarde(false);
    }
  }

  return (
    <section className="print-full overflow-hidden rounded-[2rem] border border-terre bg-white">
      {/* En-tête facture */}
      <div className="flex flex-wrap items-center justify-between gap-6 border-b-2 border-encre/85 px-6 py-7 sm:px-9">
        <div className="flex items-center gap-4">
          <LogoProprietaire src={logoUrl} className="h-16 w-16" />
          <div>
            <p className="font-display text-2xl font-black leading-none text-foret">{proprietaire}</p>
            <p className="label-marche mt-1.5 text-encre/55">
              {ville} · WhatsApp {whatsapp}
            </p>
          </div>
        </div>
        <div className="text-right">
          <p className="label-marche text-encre/50">Facture / Devis</p>
          <p className="tabulaire mt-1.5 font-display text-xl font-black text-encre">
            {new Date().toLocaleDateString("fr-FR", {
              day: "2-digit",
              month: "long",
              year: "numeric",
            })}
          </p>
          <input
            value={clientNom}
            onChange={(e) => setClientNom(e.target.value)}
            placeholder="Nom du client"
            className="mt-2 rounded-lg border border-terre px-3 py-1.5 text-right text-sm outline-none focus:border-foret"
            aria-label="Nom du client"
          />
        </div>
      </div>

      {/* Tableau */}
      <div className="overflow-x-auto">
        <table className="w-full min-w-[44rem]">
          <thead>
            <tr className="bg-nuit text-white">
              <th className={`${colonne} label-marche text-white/70`}>Produit</th>
              <th className={`${colonne} label-marche w-32 text-white/70`}>Quantité</th>
              <th className={`${colonne} label-marche w-44 text-white/70`}>Prix Unitaire FCFA</th>
              <th className={`${colonne} label-marche w-44 text-white/70`}>Total FCFA</th>
              <th className={`${colonne} w-16 no-print`} />
            </tr>
          </thead>
          <tbody>
            {lignes.map((l) => (
              <tr key={l.id} className="border-b border-terre transition-colors hover:bg-voile">
                <td className={colonne}>
                  <input
                    value={l.produit}
                    onChange={(e) => majLigne(l.id, { produit: e.target.value })}
                    placeholder="Nom du produit"
                    className="w-full rounded-lg border border-transparent bg-transparent px-2 py-2 outline-none focus:border-foret focus:bg-white"
                  />
                </td>
                <td className={colonne}>
                  <input
                    type="number"
                    min={0}
                    value={l.quantite}
                    onChange={(e) => majLigne(l.id, { quantite: Math.max(0, Number(e.target.value) || 0) })}
                    className="tabulaire w-full rounded-lg border border-terre px-3 py-2 outline-none focus:border-foret"
                  />
                </td>
                <td className={colonne}>
                  <input
                    type="number"
                    min={0}
                    value={l.prixUnitaire}
                    onChange={(e) =>
                      majLigne(l.id, { prixUnitaire: Math.max(0, Number(e.target.value) || 0) })
                    }
                    className="tabulaire w-full rounded-lg border border-terre px-3 py-2 text-ocre outline-none focus:border-foret"
                  />
                </td>
                <td className={`${colonne} tabulaire font-display text-xl font-black text-ocre`}>
                  {fcfa(l.quantite * l.prixUnitaire)}
                </td>
                <td className={`${colonne} no-print`}>
                  <button
                    type="button"
                    onClick={() => setLignes((ls) => ls.filter((x) => x.id !== l.id))}
                    className="flex h-9 w-9 items-center justify-center rounded-full border border-terre text-encre/45 transition-colors hover:border-ocre hover:text-ocre"
                    aria-label="Supprimer la ligne"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex flex-wrap items-center gap-3 border-b border-terre px-6 py-5 no-print sm:px-9">
        <button
          type="button"
          onClick={ajouterLigne}
          className="inline-flex items-center gap-2 rounded-full border border-foret px-5 py-2.5 text-sm font-semibold text-foret transition-colors hover:bg-foret hover:text-white"
        >
          <Plus className="h-4 w-4" /> Ajouter une ligne
        </button>
        <button
          type="button"
          onClick={exporterExcel}
          className="inline-flex items-center gap-2 rounded-full bg-foret px-5 py-2.5 text-sm font-semibold text-white transition-transform hover:-translate-y-0.5"
        >
          <Download className="h-4 w-4" /> Exporter Excel
        </button>
        <button
          type="button"
          onClick={() => window.print()}
          className="inline-flex items-center gap-2 rounded-full bg-travail px-5 py-2.5 text-sm font-semibold text-white transition-transform hover:-translate-y-0.5"
        >
          <Printer className="h-4 w-4" /> Exporter PDF
        </button>
        <label className="inline-flex cursor-pointer items-center gap-2 rounded-full border border-terre px-5 py-2.5 text-sm font-semibold text-encre/75 transition-colors hover:border-foret hover:text-foret">
          <FileUp className="h-4 w-4" /> Importer Excel
          <input
            type="file"
            accept=".csv,.xls,.xlsx,.txt"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) importerExcel(f);
            }}
          />
        </label>
        <button
          type="button"
          onClick={enregistrer}
          disabled={sauvegarde}
          className="inline-flex items-center gap-2 rounded-full bg-ocre px-5 py-2.5 text-sm font-semibold text-white transition-transform hover:-translate-y-0.5 disabled:opacity-60"
        >
          {sauvegarde ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          Enregistrer la facture
        </button>
      </div>

      {/* Totaux */}
      <div className="grid gap-8 px-6 py-8 sm:px-9 lg:grid-cols-[1fr_22rem]">
        <div className="rounded-2xl border border-terre bg-voile p-6">
          <p className="label-marche text-encre/55">Conditions de paiement</p>
          <p className="mt-3 leading-relaxed text-encre/75">
            Règlement par Orange Money, MTN MoMo, Wave, Carte Bancaire ou Espèces — directement sur
            le compte du propriétaire. Les marchandises restent la propriété de SBS jusqu&apos;au
            paiement complet.
          </p>
          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            <div>
              <label className="label-marche text-encre/55" htmlFor="remise">Remise (FCFA)</label>
              <input
                id="remise"
                type="number"
                min={0}
                value={remise}
                onChange={(e) => setRemise(Math.max(0, Number(e.target.value) || 0))}
                className="tabulaire mt-2 w-full rounded-xl border border-terre px-4 py-2.5 outline-none focus:border-foret"
              />
            </div>
            <div>
              <label className="label-marche text-encre/55" htmlFor="tva">TVA (%)</label>
              <input
                id="tva"
                type="number"
                min={0}
                step={0.25}
                value={tauxTva}
                onChange={(e) => setTauxTva(Math.max(0, Number(e.target.value) || 0))}
                className="tabulaire mt-2 w-full rounded-xl border border-terre px-4 py-2.5 outline-none focus:border-foret"
              />
            </div>
          </div>
          {message && (
            <p className="mt-5 rounded-xl bg-white px-4 py-3 text-sm text-foret">{message}</p>
          )}
        </div>

        <div className="rounded-2xl border-2 border-encre/85 bg-white p-6">
          <dl className="space-y-3">
            <div className="flex items-center justify-between">
              <dt className="label-marche text-encre/55">Sous-Total</dt>
              <dd className="tabulaire font-display text-xl font-black text-encre">{fcfa(sousTotal)}</dd>
            </div>
            <div className="flex items-center justify-between">
              <dt className="label-marche text-encre/55">Remise</dt>
              <dd className="tabulaire font-display text-xl font-black text-encre">
                − {fcfa(remiseMontant)}
              </dd>
            </div>
            <div className="flex items-center justify-between">
              <dt className="label-marche text-encre/55">TVA ({tauxTva} %)</dt>
              <dd className="tabulaire font-display text-xl font-black text-encre">{fcfa(tva)}</dd>
            </div>
          </dl>
          <div className="mt-5 border-t-2 border-encre/85 pt-5">
            <p className="label-marche text-ocre">Total à payer</p>
            <p className="tabulaire mt-2 font-display text-4xl font-black leading-none text-ocre">
              {fcfa(total)}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
