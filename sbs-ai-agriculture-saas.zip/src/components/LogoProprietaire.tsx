"use client";

import { useState } from "react";
import { LogoEmblem } from "./Logo";

/**
 * Logo du propriétaire avec repli automatique sur l'emblème SBS dessiné en SVG.
 * Le propriétaire peut fournir sa propre image depuis le Dashboard Admin.
 */
export default function LogoProprietaire({
  src,
  className = "h-16 w-16",
  alt = "Logo du propriétaire",
}: {
  src?: string | null;
  className?: string;
  alt?: string;
}) {
  const [erreur, setErreur] = useState(false);

  if (!src || erreur || src.includes("logo-sbs.svg")) {
    return <LogoEmblem className={className} />;
  }

  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={src}
      alt={alt}
      onError={() => setErreur(true)}
      className={`${className} rounded-2xl bg-white object-contain`}
    />
  );
}
