"use client";

import { useEffect, useRef, useState } from "react";
import { Bot, MessageCircle, Send, X, Sparkles } from "lucide-react";

type Message = { role: "moi" | "ia"; texte: string };

const SUGGESTIONS = [
  "Comment acheter du maïs ?",
  "Combien coûte l'abonnement Pro ?",
  "J'ai des taches jaunes sur mes feuilles",
  "Comment avoir mon score agricole ?",
];

export default function FloatingActions({
  whatsapp,
  proprietaire,
}: {
  whatsapp: string;
  proprietaire: string;
}) {
  const [ouvert, setOuvert] = useState(false);
  const [saisie, setSaisie] = useState("");
  const [enCours, setEnCours] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "ia",
      texte: `Bonjour ! Je suis l'IA SBS, gratuite pour tout le monde. Dis-moi ce que tu cherches : acheter un produit, voir la météo, soigner une plante ou un animal. ${proprietaire} est joignable sur WhatsApp au ${whatsapp}.`,
    },
  ]);
  const finRef = useRef<HTMLDivElement | null>(null);
  const numero = whatsapp.replace(/[^\d]/g, "");

  useEffect(() => {
    finRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, ouvert]);

  async function envoyer(texte: string) {
    const question = texte.trim();
    if (!question || enCours) return;
    setSaisie("");
    setMessages((m) => [...m, { role: "moi", texte: question }]);
    setEnCours(true);
    try {
      const rep = await fetch("/api/ia-sbs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question }),
      });
      const donnees = (await rep.json()) as { reponse?: string };
      setMessages((m) => [
        ...m,
        {
          role: "ia",
          texte: donnees.reponse ?? "Réessaie dans un instant, ou écris sur WhatsApp.",
        },
      ]);
    } catch {
      setMessages((m) => [
        ...m,
        { role: "ia", texte: "Connexion difficile. Écris directement sur WhatsApp, c'est plus rapide." },
      ]);
    } finally {
      setEnCours(false);
    }
  }

  return (
    <>
      {/* Boutons flottants */}
      <div className="no-print fixed bottom-5 right-4 z-50 flex flex-col items-end gap-3 sm:bottom-7 sm:right-6">
        <a
          href={`https://wa.me/${numero}`}
          target="_blank"
          rel="noreferrer"
          className="group flex items-center gap-3 rounded-full bg-[#25D366] px-4 py-3 font-semibold text-[#07321b] shadow-[0_18px_35px_-15px_rgba(7,50,27,0.8)] transition-transform hover:-translate-y-1"
        >
          <MessageCircle className="h-5 w-5" />
          <span className="hidden text-sm sm:inline">WhatsApp du propriétaire</span>
        </a>

        <button
          type="button"
          onClick={() => setOuvert((v) => !v)}
          className="flex items-center gap-3 rounded-full bg-foret px-5 py-4 font-semibold text-white shadow-[0_18px_40px_-14px_rgba(22,101,52,0.95)] transition-transform hover:-translate-y-1"
        >
          {ouvert ? <X className="h-5 w-5" /> : <Bot className="h-5 w-5" />}
          <span className="text-sm">{ouvert ? "Fermer" : "Parler à l'IA 🤖"}</span>
        </button>
      </div>

      {/* Panneau de conversation */}
      {ouvert && (
        <div className="no-print fixed bottom-28 right-3 z-50 flex h-[min(32rem,72vh)] w-[min(23rem,calc(100vw-1.5rem))] flex-col overflow-hidden rounded-3xl border border-terre bg-white shadow-[0_40px_90px_-30px_rgba(11,59,34,0.55)] sm:right-6">
          <div className="flex items-center gap-3 bg-nuit px-5 py-4 text-white">
            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-white/15">
              <Sparkles className="h-5 w-5 text-mangue" />
            </span>
            <div className="leading-tight">
              <p className="font-display text-lg font-black">IA SBS — gratuite</p>
              <p className="text-[0.72rem] text-white/65">
                Réponse en français simple, 3 à 4 phrases
              </p>
            </div>
          </div>

          <div className="scroll-fin flex-1 space-y-3 overflow-y-auto bg-voile px-4 py-4">
            {messages.map((m, i) => (
              <div
                key={i}
                className={
                  m.role === "moi"
                    ? "ml-auto max-w-[85%] rounded-2xl rounded-br-md bg-travail px-4 py-2.5 text-[0.88rem] leading-relaxed text-white"
                    : "mr-auto max-w-[90%] rounded-2xl rounded-bl-md border border-terre bg-white px-4 py-2.5 text-[0.88rem] leading-relaxed text-encre"
                }
              >
                {m.texte}
              </div>
            ))}
            {enCours && (
              <div className="mr-auto flex items-center gap-1.5 rounded-2xl border border-terre bg-white px-4 py-3">
                <span className="h-2 w-2 animate-bounce rounded-full bg-foret [animation-delay:-0.2s]" />
                <span className="h-2 w-2 animate-bounce rounded-full bg-foret [animation-delay:-0.1s]" />
                <span className="h-2 w-2 animate-bounce rounded-full bg-foret" />
              </div>
            )}
            <div ref={finRef} />
          </div>

          <div className="border-t border-terre bg-white px-3 pt-3">
            <div className="flex flex-wrap gap-1.5 pb-2">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => envoyer(s)}
                  className="rounded-full border border-terre bg-voile px-3 py-1.5 text-[0.72rem] text-encre/75 transition-colors hover:border-foret hover:text-foret"
                >
                  {s}
                </button>
              ))}
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                envoyer(saisie);
              }}
              className="flex items-center gap-2 pb-3"
            >
              <input
                value={saisie}
                onChange={(e) => setSaisie(e.target.value)}
                placeholder="Écris ta question ici…"
                className="min-w-0 flex-1 rounded-full border border-terre px-4 py-2.5 text-sm outline-none focus:border-foret"
                aria-label="Ta question pour l'IA SBS"
              />
              <button
                type="submit"
                disabled={enCours}
                className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-foret text-white transition-transform hover:-translate-y-0.5 disabled:opacity-50"
                aria-label="Envoyer"
              >
                <Send className="h-4 w-4" />
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
