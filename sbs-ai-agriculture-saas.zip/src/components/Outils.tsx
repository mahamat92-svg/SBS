"use client";

import { useMemo, useState } from "react";
import {
  CloudSun,
  Stethoscope,
  MessageSquareText,
  Calculator,
  Droplets,
  Gauge,
  ChevronRight,
  Loader2,
} from "lucide-react";
import { ANIMAUX, CULTURES, VILLAGES, fcfa, nombre } from "@/lib/data";
import { arrosageOuNon, diagnostic, meteoVillage, scoreAgricole } from "@/lib/ia";

type Service = "Agriculture" | "Élevage";

const ICONE = [CloudSun, Stethoscope, MessageSquareText, Calculator, Droplets, Gauge];

function titreOutil(service: Service, index: number) {
  const agri = [
    "Météo de mon champ",
    "Docteur Plante",
    "Conseil IA",
    "Ma Récolte",
    "Quand Arroser ?",
    "Mon Score Agricole",
  ];
  const elev = [
    "Météo de mon champ",
    "Docteur Animal",
    "Conseil IA",
    "Mon Élevage",
    "Quand Nourrir ?",
    "Mon Score Agricole",
  ];
  return (service === "Agriculture" ? agri : elev)[index];
}

function resumeOutil(service: Service, index: number) {
  const agri = [
    "La pluie et la chaleur de votre village",
    "Photo d'une feuille malade → traitement",
    "Une question en français simple",
    "Surface + semis = sacs et FCFA",
    "Arrosez aujourd'hui ou non",
    "Votre note de 0 à 100",
  ];
  const elev = [
    "La pluie et la chaleur de votre village",
    "Un animal malade → maladie + soin",
    "Une question en français simple",
    "Animaux + poids = valeur en FCFA",
    "Nourrissez aujourd'hui ou non",
    "Votre note de 0 à 100",
  ];
  return (service === "Agriculture" ? agri : elev)[index];
}

const champStyle =
  "w-full rounded-xl border border-terre bg-white px-4 py-3 text-[0.95rem] outline-none transition-colors focus:border-foret";
const boutonPrimaire =
  "inline-flex items-center justify-center gap-2 rounded-full bg-foret px-6 py-3.5 text-sm font-semibold text-white transition-transform hover:-translate-y-0.5 disabled:opacity-60";

function Bloc({ children, titre, sousTitre }: { children: React.ReactNode; titre: string; sousTitre: string }) {
  return (
    <div>
      <p className="label-marche text-foret">outil en fonctionnement</p>
      <h3 className="mt-2 font-display text-3xl font-black leading-[1.05] text-encre sm:text-4xl">{titre}</h3>
      <p className="mt-3 max-w-xl text-[1.02rem] leading-relaxed text-encre/70">{sousTitre}</p>
      <div className="mt-8">{children}</div>
    </div>
  );
}

function CarteResultat({ children, accent = "vert" }: { children: React.ReactNode; accent?: "vert" | "ocre" | "bleu" }) {
  const bords = {
    vert: "border-foret/30 bg-[#eef6f0]",
    ocre: "border-ocre/30 bg-[#fdf1e9]",
    bleu: "border-travail/25 bg-[#eef2fd]",
  } as const;
  return (
    <div className={`rounded-2xl border-2 ${bords[accent]} p-6 sm:p-7`}>{children}</div>
  );
}

export default function Outils({ service }: { service: Service }) {
  const [actif, setActif] = useState(0);

  return (
    <section className="mx-auto max-w-7xl px-4 pb-8 sm:px-6 lg:px-8">
      <div className="grid gap-10 lg:grid-cols-[19rem_1fr]">
        {/* Rail collant */}
        <aside className="lg:sticky lg:top-24 lg:self-start">
          <p className="label-marche text-encre/50">Les 6 outils IA</p>
          <ol className="mt-5 space-y-1.5">
            {titreOutil(service, 0) && [0, 1, 2, 3, 4, 5].map((i) => {
              const Icone = ICONE[i];
              const estActif = actif === i;
              return (
                <li key={i}>
                  <button
                    type="button"
                    onClick={() => setActif(i)}
                    className={`flex w-full items-center gap-3 rounded-2xl border px-4 py-3 text-left transition-all ${
                      estActif
                        ? "border-foret bg-nuit text-white shadow-[0_18px_35px_-18px_rgba(11,59,34,0.9)]"
                        : "border-terre bg-white text-encre hover:border-foret/50 hover:bg-voile"
                    }`}
                  >
                    <span
                      className={`tabulaire text-xs font-bold ${estActif ? "text-mangue" : "text-encre/40"}`}
                    >
                      0{i + 1}
                    </span>
                    <Icone className={`h-4.5 w-4.5 ${estActif ? "text-mangue" : "text-foret"}`} />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[0.92rem] font-semibold">{titreOutil(service, i)}</span>
                      <span className={`block truncate text-[0.72rem] ${estActif ? "text-white/60" : "text-encre/50"}`}>
                        {resumeOutil(service, i)}
                      </span>
                    </span>
                    <ChevronRight className={`h-4 w-4 shrink-0 ${estActif ? "text-white/70" : "text-encre/25"}`} />
                  </button>
                </li>
              );
            })}
          </ol>
          <div className="mt-6 rounded-2xl border border-terre bg-white p-5">
            <p className="text-sm leading-relaxed text-encre/70">
              Tous ces outils sont <strong className="text-foret">gratuits pour découvrir</strong>.
              Sans limite, ils sont inclus dans l&apos;abonnement Pro à 5 000 FCFA par mois.
            </p>
            <a
              href="/#offres"
              className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-travail lien-souligne"
            >
              Voir les offres <ChevronRight className="h-4 w-4" />
            </a>
          </div>
        </aside>

        {/* Panneau de travail */}
        <div className="rounded-3xl border border-terre bg-white p-6 shadow-[0_30px_70px_-45px_rgba(11,59,34,0.5)] sm:p-10">
          {actif === 0 && <Meteo />}
          {actif === 1 && <Docteur service={service} />}
          {actif === 2 && <Conseil />}
          {actif === 3 && <Calcul service={service} />}
          {actif === 4 && <Arrosage service={service} />}
          {actif === 5 && <Score service={service} />}
        </div>
      </div>
    </section>
  );
}

/* ---------------- 01 Météo ---------------- */
function Meteo() {
  const [village, setVillage] = useState(VILLAGES[0].nom);
  const [vu, setVu] = useState(false);
  const m = useMemo(() => meteoVillage(village), [village]);

  return (
    <Bloc
      titre="Météo de mon champ"
      sousTitre="Choisissez votre village au Cameroun ou au Tchad : vous voyez la pluie, la chaleur et le conseil du jour."
    >
      <div className="flex flex-col gap-3 sm:flex-row">
        <select
          value={village}
          onChange={(e) => {
            setVillage(e.target.value);
            setVu(true);
          }}
          className={champStyle}
          aria-label="Votre village"
        >
          {VILLAGES.map((v) => (
            <option key={v.nom} value={v.nom}>
              {v.nom} — {v.region}, {v.pays}
            </option>
          ))}
        </select>
        <button type="button" onClick={() => setVu(true)} className={boutonPrimaire}>
          <CloudSun className="h-4 w-4" /> Voir la météo
        </button>
      </div>

      {vu && (
        <div className="mt-7">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {[
              { l: "Température", v: `${m.temperature}°C` },
              { l: "Pluie prévue", v: `${m.pluie} mm` },
              { l: "Humidité", v: `${m.humidite}%` },
              { l: "Vent", v: `${m.vent} km/h` },
            ].map((x) => (
              <div key={x.l} className="rounded-2xl border border-terre bg-voile px-4 py-5">
                <p className="label-marche text-encre/50">{x.l}</p>
                <p className="tabulaire mt-2 font-display text-3xl font-black text-foret">{x.v}</p>
              </div>
            ))}
          </div>
          <div className="mt-4">
            <CarteResultat accent={m.pluie > 6 ? "bleu" : "ocre"}>
              <p className="label-marche text-encre/55">Conseil du jour — {m.village}</p>
              <p className="mt-2 text-lg leading-relaxed text-encre">{m.conseil}</p>
            </CarteResultat>
          </div>
        </div>
      )}
    </Bloc>
  );
}

/* ---------------- 02 Docteur ---------------- */
function Docteur({ service }: { service: Service }) {
  const [description, setDescription] = useState("");
  const [photo, setPhoto] = useState<string | null>(null);
  const [analyse, setAnalyse] = useState<ReturnType<typeof diagnostic> | null>(null);

  return (
    <Bloc
      titre={service === "Agriculture" ? "Docteur Plante" : "Docteur Animal"}
      sousTitre={
        service === "Agriculture"
          ? "Décrivez la feuille ou envoyez sa photo : taches, jaunissement, insectes… Vous recevez la maladie et le traitement."
          : "Décrivez l'animal malade ou envoyez sa photo : boiterie, diarrhée, toux, gale… Vous recevez la maladie et le traitement."
      }
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label className="label-marche text-encre/55" htmlFor="desc-maladie">
            Ce que vous voyez
          </label>
          <textarea
            id="desc-maladie"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={5}
            placeholder={
              service === "Agriculture"
                ? "Exemple : les feuilles du bas sont jaunes avec des taches brunes"
                : "Exemple : ma chèvre boite et ne mange plus depuis 2 jours"
            }
            className={`${champStyle} mt-2 resize-none`}
          />
        </div>
        <div>
          <label className="label-marche text-encre/55" htmlFor="photo-maladie">
            Photo (facultative)
          </label>
          <div className="mt-2 flex h-[8.6rem] items-center justify-center overflow-hidden rounded-xl border-2 border-dashed border-terre bg-voile">
            {photo ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={photo} alt="Photo de la maladie" className="h-full w-full object-cover" />
            ) : (
              <p className="px-6 text-center text-sm text-encre/45">
                Prenez une photo nette, en plein soleil
              </p>
            )}
          </div>
          <input
            id="photo-maladie"
            type="file"
            accept="image/*"
            className="mt-3 block w-full text-sm text-encre/60 file:mr-3 file:rounded-full file:border-0 file:bg-foret file:px-4 file:py-2 file:text-sm file:font-semibold file:text-white"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) setPhoto(URL.createObjectURL(f));
            }}
          />
        </div>
      </div>

      <button
        type="button"
        disabled={description.trim().length < 3 && !photo}
        onClick={() => setAnalyse(diagnostic(service === "Agriculture" ? "plante" : "animal", description || "faiblesse"))}
        className={`${boutonPrimaire} mt-5`}
      >
        <Stethoscope className="h-4 w-4" /> Diagnostiquer maintenant
      </button>

      {analyse && (
        <div className="mt-7">
          <CarteResultat accent="ocre">
            <p className="label-marche text-ocre">Maladie détectée</p>
            <p className="mt-2 font-display text-2xl font-black text-encre">{analyse.maladie}</p>
            <p className="label-marche mt-6 text-ocre">Traitement</p>
            <p className="mt-2 whitespace-pre-line text-lg leading-relaxed text-encre">
              {analyse.traitement}
            </p>
            <p className="mt-5 border-t border-ocre/20 pt-4 text-sm text-encre/65">
              Si le problème continue après 3 jours, montrez la photo à un
              {service === "Agriculture" ? " agronome" : " vétérinaire"} ou écrivez au propriétaire
              sur WhatsApp.
            </p>
          </CarteResultat>
        </div>
      )}
    </Bloc>
  );
}

/* ---------------- 03 Conseil IA ---------------- */
function Conseil() {
  const [question, setQuestion] = useState("");
  const [reponse, setReponse] = useState("");
  const [chargement, setChargement] = useState(false);

  async function poser() {
    if (!question.trim()) return;
    setChargement(true);
    setReponse("");
    try {
      const rep = await fetch("/api/ia-sbs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question }),
      });
      const d = (await rep.json()) as { reponse?: string };
      setReponse(d.reponse ?? "Réessayez dans un instant.");
    } catch {
      setReponse("Connexion difficile. Réessayez ou écrivez sur WhatsApp.");
    } finally {
      setChargement(false);
    }
  }

  return (
    <Bloc
      titre="Conseil IA"
      sousTitre="Posez votre question en français simple. L'IA répond tout de suite, gratuitement, avec les mots de la terre."
    >
      <label className="label-marche text-encre/55" htmlFor="question-ia">
        Votre question
      </label>
      <textarea
        id="question-ia"
        rows={4}
        value={question}
        onChange={(e) => setQuestion(e.target.value)}
        placeholder="Exemples : Comment planter le maïs ? / Quand vendre mes chèvres ? / Comment garder mes arachides ?"
        className={`${champStyle} mt-2 resize-none`}
      />
      <button type="button" onClick={poser} disabled={chargement} className={`${boutonPrimaire} mt-4`}>
        {chargement ? <Loader2 className="h-4 w-4 animate-spin" /> : <MessageSquareText className="h-4 w-4" />}
        Demander conseil
      </button>

      {reponse && (
        <div className="mt-6">
          <CarteResultat accent="vert">
            <p className="label-marche text-foret">Réponse de l&apos;IA SBS</p>
            <p className="mt-3 text-lg leading-relaxed text-encre">{reponse}</p>
          </CarteResultat>
        </div>
      )}
    </Bloc>
  );
}

/* ---------------- 04 Calcul ---------------- */
function Calcul({ service }: { service: Service }) {
  const [culture, setCulture] = useState(CULTURES[0].id);
  const [surface, setSurface] = useState(1);
  const [semis, setSemis] = useState(() => new Date().toISOString().slice(0, 10));
  const [espece, setEspece] = useState(ANIMAUX[0].id);
  const [nombreAnimaux, setNombre] = useState(5);
  const [poids, setPoids] = useState(ANIMAUX[0].poidsKg);
  const [prixKg, setPrixKg] = useState(ANIMAUX[0].prixKg);

  if (service === "Agriculture") {
    const c = CULTURES.find((x) => x.id === culture) ?? CULTURES[0];
    const sacs = surface * c.rendementSacsHa;
    const valeur = sacs * c.prixSac;
    const dateRecolte = new Date(semis);
    dateRecolte.setDate(dateRecolte.getDate() + c.cycleJours);
    return (
      <Bloc
        titre="Ma Récolte"
        sousTitre="Entrez votre surface et votre date de semis : SBS calcule le nombre de sacs et le montant en FCFA."
      >
        <div className="grid gap-4 sm:grid-cols-3">
          <div>
            <label className="label-marche text-encre/55" htmlFor="culture">Culture</label>
            <select id="culture" value={culture} onChange={(e) => setCulture(e.target.value)} className={`${champStyle} mt-2`}>
              {CULTURES.map((x) => (
                <option key={x.id} value={x.id}>{x.nom}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label-marche text-encre/55" htmlFor="surface">Surface (hectares)</label>
            <input
              id="surface"
              type="number"
              min={0.1}
              step={0.1}
              value={surface}
              onChange={(e) => setSurface(Math.max(0, Number(e.target.value) || 0))}
              className={`${champStyle} tabulaire mt-2`}
            />
          </div>
          <div>
            <label className="label-marche text-encre/55" htmlFor="semis">Date de semis</label>
            <input
              id="semis"
              type="date"
              value={semis}
              onChange={(e) => setSemis(e.target.value)}
              className={`${champStyle} tabulaire mt-2`}
            />
          </div>
        </div>

        <div className="mt-7 grid gap-3 sm:grid-cols-3">
          <div className="rounded-2xl border border-terre bg-voile p-6">
            <p className="label-marche text-encre/55">Nombre de sacs</p>
            <p className="tabulaire mt-2 font-display text-4xl font-black text-foret">{nombre(sacs)}</p>
            <p className="mt-1 text-sm text-encre/55">de {c.sacKg} kg — {c.rendementSacsHa} sacs / ha</p>
          </div>
          <div className="rounded-2xl border-2 border-ocre/40 bg-[#fdf1e9] p-6">
            <p className="label-marche text-ocre">Valeur de la récolte</p>
            <p className="tabulaire mt-2 font-display text-4xl font-black text-ocre">{fcfa(valeur)}</p>
            <p className="mt-1 text-sm text-encre/60">à {fcfa(c.prixSac)} le sac</p>
          </div>
          <div className="rounded-2xl border border-terre bg-voile p-6">
            <p className="label-marche text-encre/55">Date de récolte</p>
            <p className="tabulaire mt-2 font-display text-2xl font-black text-foret">
              {dateRecolte.toLocaleDateString("fr-FR", { day: "2-digit", month: "long", year: "numeric" })}
            </p>
            <p className="mt-1 text-sm text-encre/55">cycle de {c.cycleJours} jours</p>
          </div>
        </div>

        <div className="mt-4">
          <CarteResultat accent="vert">
            <p className="label-marche text-foret">Conseil — {c.nom}</p>
            <p className="mt-2 text-lg leading-relaxed text-encre">{c.note}</p>
            <p className="mt-2 text-sm text-encre/65">
              Semis conseillé : {c.semis}. Arrosage : tous les {c.arrosageJours} jours.
            </p>
          </CarteResultat>
        </div>
      </Bloc>
    );
  }

  const a = ANIMAUX.find((x) => x.id === espece) ?? ANIMAUX[0];
  const totalKg = nombreAnimaux * poids;
  const valeur = totalKg * prixKg;
  const gainTotal = nombreAnimaux * a.gainJourKg * a.joursGras * prixKg;
  return (
    <Bloc
      titre="Mon Élevage"
      sousTitre="Entrez le nombre d'animaux, le poids moyen et le prix au kilo : SBS donne la valeur totale de votre troupeau."
    >
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <label className="label-marche text-encre/55" htmlFor="espece">Espèce</label>
          <select
            id="espece"
            value={espece}
            onChange={(e) => {
              const x = ANIMAUX.find((y) => y.id === e.target.value) ?? ANIMAUX[0];
              setEspece(x.id);
              setPoids(x.poidsKg);
              setPrixKg(x.prixKg);
            }}
            className={`${champStyle} mt-2`}
          >
            {ANIMAUX.map((x) => (
              <option key={x.id} value={x.id}>{x.nom}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="label-marche text-encre/55" htmlFor="nb-animaux">Nombre d&apos;animaux</label>
          <input
            id="nb-animaux"
            type="number"
            min={1}
            value={nombreAnimaux}
            onChange={(e) => setNombre(Math.max(0, Number(e.target.value) || 0))}
            className={`${champStyle} tabulaire mt-2`}
          />
        </div>
        <div>
          <label className="label-marche text-encre/55" htmlFor="poids">Poids moyen (kg)</label>
          <input
            id="poids"
            type="number"
            min={0}
            value={poids}
            onChange={(e) => setPoids(Math.max(0, Number(e.target.value) || 0))}
            className={`${champStyle} tabulaire mt-2`}
          />
        </div>
        <div>
          <label className="label-marche text-encre/55" htmlFor="prix-kg">Prix du kilo (FCFA)</label>
          <input
            id="prix-kg"
            type="number"
            min={0}
            value={prixKg}
            onChange={(e) => setPrixKg(Math.max(0, Number(e.target.value) || 0))}
            className={`${champStyle} tabulaire mt-2`}
          />
        </div>
      </div>

      <div className="mt-7 grid gap-3 sm:grid-cols-3">
        <div className="rounded-2xl border border-terre bg-voile p-6">
          <p className="label-marche text-encre/55">Poids total</p>
          <p className="tabulaire mt-2 font-display text-4xl font-black text-foret">{nombre(totalKg)} kg</p>
        </div>
        <div className="rounded-2xl border-2 border-ocre/40 bg-[#fdf1e9] p-6">
          <p className="label-marche text-ocre">Valeur du troupeau</p>
          <p className="tabulaire mt-2 font-display text-4xl font-black text-ocre">{fcfa(valeur)}</p>
        </div>
        <div className="rounded-2xl border border-terre bg-voile p-6">
          <p className="label-marche text-encre/55">Gain possible en {a.joursGras} jours</p>
          <p className="tabulaire mt-2 font-display text-3xl font-black text-travail">+ {fcfa(gainTotal)}</p>
        </div>
      </div>

      <div className="mt-4">
        <CarteResultat accent="vert">
          <p className="label-marche text-foret">Conseil — {a.nom}</p>
          <p className="mt-2 text-lg leading-relaxed text-encre">{a.note}</p>
          <p className="mt-2 text-sm text-encre/65">Nourriture : {a.nourritureJours} fois par jour.</p>
        </CarteResultat>
      </div>
    </Bloc>
  );
}

/* ---------------- 05 Arroser / Nourrir ---------------- */
function Arrosage({ service }: { service: Service }) {
  const [village, setVillage] = useState(VILLAGES[0].nom);
  const [culture, setCulture] = useState(service === "Agriculture" ? "maïs" : "vaches");
  const [jours, setJours] = useState(3);
  const [verdict, setVerdict] = useState<ReturnType<typeof arrosageOuNon> | null>(null);

  const options = service === "Agriculture" ? CULTURES.map((c) => c.nom) : ANIMAUX.map((a) => a.nom);

  return (
    <Bloc
      titre={service === "Agriculture" ? "Quand Arroser ?" : "Quand Nourrir ?"}
      sousTitre={
        service === "Agriculture"
          ? "Répondez à 2 questions : vous savez tout de suite s'il faut arroser aujourd'hui."
          : "Répondez à 2 questions : vous savez tout de suite s'il faut nourrir aujourd'hui et à quelle fréquence."
      }
    >
      <div className="grid gap-4 sm:grid-cols-3">
        <div>
          <label className="label-marche text-encre/55" htmlFor="village-arrosage">Village</label>
          <select id="village-arrosage" value={village} onChange={(e) => setVillage(e.target.value)} className={`${champStyle} mt-2`}>
            {VILLAGES.map((v) => (
              <option key={v.nom} value={v.nom}>{v.nom}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="label-marche text-encre/55" htmlFor="culture-arrosage">
            {service === "Agriculture" ? "Culture" : "Animal"}
          </label>
          <select id="culture-arrosage" value={culture} onChange={(e) => setCulture(e.target.value)} className={`${champStyle} mt-2`}>
            {options.map((o) => (
              <option key={o} value={o}>{o}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="label-marche text-encre/55" htmlFor="jours-arrosage">
            {service === "Agriculture" ? "Jours depuis le dernier arrosage" : "Repas depuis la dernière distribution"}
          </label>
          <input
            id="jours-arrosage"
            type="number"
            min={0}
            value={jours}
            onChange={(e) => setJours(Math.max(0, Number(e.target.value) || 0))}
            className={`${champStyle} tabulaire mt-2`}
          />
        </div>
      </div>

      <button type="button" onClick={() => setVerdict(arrosageOuNon(village, jours, culture))} className={`${boutonPrimaire} mt-5`}>
        <Droplets className="h-4 w-4" />
        {service === "Agriculture" ? "Vérifier l'arrosage" : "Vérifier le repas"}
      </button>

      {verdict && (
        <div className="mt-7">
          <div
            className={`rounded-3xl p-8 text-center ${
              verdict.verdict.startsWith("ARROSE")
                ? "bg-foret text-white"
                : "border-2 border-terre bg-white text-encre"
            }`}
          >
            <p className="label-marche opacity-70">Décision du jour</p>
            <p className="mt-3 font-display text-4xl font-black leading-none sm:text-5xl">{verdict.verdict}</p>
            <p className={`mx-auto mt-4 max-w-xl text-lg ${verdict.verdict.startsWith("ARROSE") ? "text-white/85" : "text-encre/70"}`}>
              {verdict.explication}
            </p>
            <p className={`tabulaire mt-4 text-sm ${verdict.verdict.startsWith("ARROSE") ? "text-white/70" : "text-encre/55"}`}>
              Fréquence conseillée : {verdict.frequence}
            </p>
          </div>
        </div>
      )}
    </Bloc>
  );
}

/* ---------------- 06 Score ---------------- */
function Score({ service }: { service: Service }) {
  const [surface, setSurface] = useState(1.5);
  const [etat, setEtat] = useState({
    irrigation: true,
    fumure: true,
    analyseSol: false,
    protection: false,
    diversification: true,
  });
  const [calcule, setCalcule] = useState(false);
  const r = scoreAgricole({ surface, ...etat });

  const questions: { cle: keyof typeof etat; texte: string }[] = [
    { cle: "irrigation", texte: service === "Agriculture" ? "J'ai un point d'eau pour arroser" : "J'ai un point d'eau pour le troupeau" },
    { cle: "fumure", texte: "J'utilise du fumier ou du compost" },
    { cle: "analyseSol", texte: "J'ai fait analyser mon sol ou mes fourrages" },
    { cle: "protection", texte: "Je protège mes cultures / mes animaux (vaccins, filets)" },
    { cle: "diversification", texte: "Je fais plusieurs cultures ou plusieurs espèces" },
  ];

  return (
    <Bloc
      titre="Mon Score Agricole"
      sousTitre="Répondez à 6 questions courtes : vous recevez une note de 0 à 100 et les points précis à améliorer."
    >
      <div>
        <label className="label-marche text-encre/55" htmlFor="surface-score">
          {service === "Agriculture" ? "Surface cultivée (hectares)" : "Taille du troupeau (têtes)"}
        </label>
        <input
          id="surface-score"
          type="number"
          min={0}
          step={0.5}
          value={surface}
          onChange={(e) => {
            setSurface(Math.max(0, Number(e.target.value) || 0));
            setCalcule(true);
          }}
          className={`${champStyle} tabulaire mt-2 max-w-xs`}
        />
      </div>

      <ul className="mt-6 space-y-2">
        {questions.map((q) => {
          const on = etat[q.cle];
          return (
            <li key={q.cle}>
              <button
                type="button"
                onClick={() => {
                  setEtat((s) => ({ ...s, [q.cle]: !s[q.cle] }));
                  setCalcule(true);
                }}
                className={`flex w-full items-center gap-4 rounded-2xl border px-5 py-4 text-left transition-colors ${
                  on ? "border-foret bg-[#eef6f0]" : "border-terre bg-white hover:bg-voile"
                }`}
              >
                <span
                  className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-2 ${
                    on ? "border-foret bg-foret text-white" : "border-terre text-transparent"
                  }`}
                >
                  ✓
                </span>
                <span className="text-[0.98rem] text-encre">{q.texte}</span>
              </button>
            </li>
          );
        })}
      </ul>

      <button type="button" onClick={() => setCalcule(true)} className={`${boutonPrimaire} mt-5`}>
        <Gauge className="h-4 w-4" /> Calculer mon score
      </button>

      {calcule && (
        <div className="mt-8 rounded-3xl border-2 border-terre bg-white p-7">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="label-marche text-encre/55">{r.niveau}</p>
              <p className="tabulaire font-display text-6xl font-black leading-none text-foret">
                {r.score}
                <span className="text-2xl text-encre/40">/100</span>
              </p>
            </div>
            <div className="h-32 w-32">
              <svg viewBox="0 0 120 120" className="h-full w-full -rotate-90">
                <circle cx="60" cy="60" r="50" fill="none" stroke="#e6ede7" strokeWidth="12" />
                <circle
                  cx="60"
                  cy="60"
                  r="50"
                  fill="none"
                  stroke="#166534"
                  strokeWidth="12"
                  strokeLinecap="round"
                  strokeDasharray={`${(r.score / 100) * 314} 314`}
                  style={{ transition: "stroke-dasharray 0.9s cubic-bezier(0.22,1,0.36,1)" }}
                />
              </svg>
            </div>
          </div>
          <ul className="mt-6 space-y-2">
            {r.conseils.map((c) => (
              <li key={c} className="flex items-start gap-3 rounded-xl bg-voile px-4 py-3 text-[0.95rem] text-encre/80">
                <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-ocre" />
                {c}
              </li>
            ))}
          </ul>
        </div>
      )}
    </Bloc>
  );
}
