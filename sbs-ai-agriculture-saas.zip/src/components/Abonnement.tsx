"use client";

import { useState } from "react";
import { Check, Loader2, X, ShieldCheck, Smartphone, CreditCard, Banknote } from "lucide-react";
import { METHODES_PAIEMENT, OFFRES, fcfa } from "@/lib/data";
import { IconeFacebook } from "./IconeFacebook";

type Comptes = Record<string, string>;

const ICONE_METHODE: Record<string, typeof Smartphone> = {
  "Orange Money": Smartphone,
  "MTN MoMo": Smartphone,
  Wave: Smartphone,
  "Carte Bancaire": CreditCard,
  Espèces: Banknote,
};

export default function Abonnement({ comptes }: { comptes: Comptes }) {
  const [choix, setChoix] = useState<string | null>(null);
  const [methode, setMethode] = useState<string>("Orange Money");
  const [form, setForm] = useState({
    nom: "",
    telephone: "",
    village: "",
    service: "Agriculture",
    lienFacebook: "",
  });
  const [enCours, setEnCours] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [erreur, setErreur] = useState<string | null>(null);

  const offre = OFFRES.find((o) => o.id === choix);

  async function payer() {
    if (!offre) return;
    setErreur(null);
    if (!form.nom.trim() || !form.telephone.trim()) {
      setErreur("Écrivez au moins votre nom et votre numéro de téléphone.");
      return;
    }
    setEnCours(true);
    try {
      const rep = await fetch("/api/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, offre: offre.nom, montant: offre.prix, methode }),
      });
      const d = (await rep.json()) as { message?: string; erreur?: string; compteProprietaire?: string };
      if (d.erreur) {
        setErreur(d.erreur);
      } else {
        setMessage(
          `${d.message ?? "Paiement enregistré."} Envoyez maintenant ${fcfa(offre.prix)} au ${d.compteProprietaire ?? "compte du propriétaire"} (${methode}), puis envoyez la capture sur WhatsApp.`,
        );
      }
    } catch {
      setErreur("Le paiement n'a pas abouti. Réessayez ou payez par WhatsApp.");
    } finally {
      setEnCours(false);
    }
  }

  return (
    <section id="offres" className="relative overflow-hidden bg-nuit py-20 text-white">
      <div
        className="absolute inset-0 opacity-[0.14]"
        style={{ backgroundImage: "url(images/elevage-zebu.jpg)", backgroundSize: "cover", backgroundPosition: "center" }}
        aria-hidden
      />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl">
          <p className="label-marche text-mangue">Abonnements</p>
          <h2 className="mt-4 font-display text-4xl font-black leading-[1.02] sm:text-6xl">
            L&apos;argent va directement sur <em className="not-italic text-mangue">le compte du propriétaire</em>.
          </h2>
          <p className="mt-5 text-lg leading-relaxed text-white/75">
            Pas d&apos;intermédiaire : vous payez par Orange Money, MTN MoMo, Wave, Carte Bancaire ou
            Espèces, et le solde de {`M. le propriétaire`} augmente tout seul dans son tableau de bord.
          </p>
        </div>

        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          {OFFRES.map((o) => {
            const vedette = o.id === "pro";
            return (
              <article
                key={o.id}
                className={`relative flex flex-col rounded-3xl p-8 ${
                  vedette
                    ? "bg-white text-encre shadow-[0_45px_90px_-40px_rgba(0,0,0,0.75)] lg:-translate-y-4"
                    : "border border-white/15 bg-white/[0.06] text-white"
                }`}
              >
                {vedette && (
                  <span className="label-marche absolute -top-3 left-8 rounded-full bg-ocre px-4 py-1.5 text-white">
                    Le plus choisi
                  </span>
                )}
                <p className={`label-marche ${vedette ? "text-foret" : "text-mangue"}`}>{o.nom}</p>
                <p className="mt-4 flex items-end gap-2">
                  <span className="tabulaire font-display text-5xl font-black leading-none">
                    {o.prix === 0 ? "0" : o.prix.toLocaleString("fr-FR")}
                  </span>
                  <span className={`pb-1 text-sm ${vedette ? "text-encre/55" : "text-white/60"}`}>
                    FCFA {o.periode}
                  </span>
                </p>
                <ul className="mt-7 space-y-3">
                  {o.inclus.map((i) => (
                    <li key={i} className="flex items-start gap-3 text-[0.95rem]">
                      <Check className={`mt-0.5 h-4 w-4 shrink-0 ${vedette ? "text-foret" : "text-mangue"}`} />
                      <span className={vedette ? "text-encre/75" : "text-white/75"}>{i}</span>
                    </li>
                  ))}
                </ul>
                <button
                  type="button"
                  onClick={() => {
                    setChoix(o.id);
                    setMessage(null);
                    setErreur(null);
                  }}
                  className={`mt-8 w-full rounded-full px-6 py-3.5 text-sm font-semibold transition-transform hover:-translate-y-0.5 ${
                    vedette ? "bg-foret text-white" : "bg-white text-nuit"
                  }`}
                >
                  {o.prix === 0 ? "Commencer gratuitement" : `S'abonner — ${o.nom}`}
                </button>
              </article>
            );
          })}
        </div>

        <div className="mt-12 flex flex-wrap items-center gap-x-8 gap-y-3 text-sm text-white/65">
          <span className="inline-flex items-center gap-2">
            <ShieldCheck className="h-4 w-4 text-mangue" /> Paiement sécurisé sur le compte du propriétaire
          </span>
          {METHODES_PAIEMENT.map((m) => (
            <span key={m} className="inline-flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-mangue" /> {m}
            </span>
          ))}
        </div>
      </div>

      {/* Modale de paiement */}
      {choix && offre && (
        <div className="fixed inset-0 z-[60] flex items-end justify-center bg-nuit/70 p-3 backdrop-blur-sm sm:items-center sm:p-6">
          <div className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-3xl bg-white p-6 text-encre shadow-2xl sm:p-9">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="label-marche text-foret">Abonnement {offre.nom}</p>
                <p className="mt-2 font-display text-3xl font-black">
                  <span className="tabulaire">{offre.prix === 0 ? "Gratuit" : fcfa(offre.prix)}</span>
                  <span className="ml-2 text-base font-medium text-encre/55">{offre.periode}</span>
                </p>
              </div>
              <button
                type="button"
                onClick={() => setChoix(null)}
                className="flex h-10 w-10 items-center justify-center rounded-full border border-terre text-encre/60 hover:border-foret hover:text-foret"
                aria-label="Fermer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <p className="label-marche mt-8 text-encre/55">1. Choisissez votre moyen de paiement</p>
            <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-5">
              {METHODES_PAIEMENT.map((m) => {
                const Icone = ICONE_METHODE[m] ?? Smartphone;
                return (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setMethode(m)}
                    className={`flex flex-col items-center gap-2 rounded-2xl border px-3 py-4 text-[0.72rem] font-semibold transition-colors ${
                      methode === m ? "border-foret bg-[#eef6f0] text-foret" : "border-terre text-encre/70 hover:border-foret/50"
                    }`}
                  >
                    <Icone className="h-5 w-5" />
                    {m}
                  </button>
                );
              })}
            </div>

            <div className="mt-4 rounded-2xl border-2 border-dashed border-foret/40 bg-voile px-5 py-4">
              <p className="label-marche text-foret">Compte du propriétaire — {methode}</p>
              <p className="tabulaire mt-2 font-display text-2xl font-black text-encre">
                {comptes[methode] ?? "Contactez le propriétaire"}
              </p>
              <p className="mt-1 text-sm text-encre/60">
                Cet argent est reçu directement par le propriétaire de SBS, jamais par un intermédiaire.
              </p>
            </div>

            <p className="label-marche mt-8 text-encre/55">2. Vos informations</p>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <input
                placeholder="Votre nom complet"
                value={form.nom}
                onChange={(e) => setForm({ ...form, nom: e.target.value })}
                className="rounded-xl border border-terre px-4 py-3 outline-none focus:border-foret"
              />
              <input
                placeholder="Votre numéro de téléphone"
                value={form.telephone}
                onChange={(e) => setForm({ ...form, telephone: e.target.value })}
                className="tabulaire rounded-xl border border-terre px-4 py-3 outline-none focus:border-foret"
              />
              <input
                placeholder="Votre village (ex : Ngaoundéré)"
                value={form.village}
                onChange={(e) => setForm({ ...form, village: e.target.value })}
                className="rounded-xl border border-terre px-4 py-3 outline-none focus:border-foret"
              />
              <select
                value={form.service}
                onChange={(e) => setForm({ ...form, service: e.target.value })}
                className="rounded-xl border border-terre px-4 py-3 outline-none focus:border-foret"
              >
                <option>Agriculture</option>
                <option>Élevage</option>
              </select>
              <div className="relative sm:col-span-2">
                <IconeFacebook className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-[#1877F2]" />
                <input
                  placeholder="Lien Facebook (facultatif) — https://facebook.com/votre-page"
                  value={form.lienFacebook}
                  onChange={(e) => setForm({ ...form, lienFacebook: e.target.value })}
                  className="w-full rounded-xl border border-terre py-3 pl-12 pr-4 outline-none focus:border-foret"
                />
              </div>
            </div>

            {erreur && (
              <p className="mt-4 rounded-xl bg-[#fdecea] px-4 py-3 text-sm text-[#9b2c1c]">{erreur}</p>
            )}
            {message && (
              <p className="mt-4 rounded-xl bg-[#eef6f0] px-4 py-3 text-sm leading-relaxed text-foret">
                {message}
              </p>
            )}

            <button
              type="button"
              onClick={payer}
              disabled={enCours}
              className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-foret px-6 py-4 text-sm font-semibold text-white transition-transform hover:-translate-y-0.5 disabled:opacity-60"
            >
              {enCours ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
              Valider le paiement de {offre.prix === 0 ? "l'essai gratuit" : fcfa(offre.prix)}
            </button>
            <p className="mt-3 text-center text-xs text-encre/50">
              Le solde du propriétaire augmente automatiquement dès la validation.
            </p>
          </div>
        </div>
      )}
    </section>
  );
}
