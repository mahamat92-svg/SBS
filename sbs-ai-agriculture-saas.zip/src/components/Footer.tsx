import Link from "next/link";
import { MessageCircle, Mail, MapPin } from "lucide-react";
import { LogoEmblem } from "./Logo";
import { IconeFacebook } from "./IconeFacebook";

export default function Footer({
  nom,
  whatsapp,
  proprietaire,
  ville,
  pays,
  email,
}: {
  nom: string;
  whatsapp: string;
  proprietaire: string;
  ville: string;
  pays: string;
  email: string;
}) {
  const numero = whatsapp.replace(/[^\d]/g, "");
  return (
    <footer className="relative mt-24 overflow-hidden bg-nuit text-white">
      <div
        className="absolute inset-0 opacity-[0.16]"
        style={{
          backgroundImage: "url(images/hero-champ.jpg)",
          backgroundSize: "cover",
          backgroundPosition: "center",
          filter: "grayscale(0.4)",
        }}
        aria-hidden
      />
      <div className="relative mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-12 md:grid-cols-[1.4fr_1fr_1fr_1.1fr]">
          <div>
            <div className="flex items-center gap-4">
              <LogoEmblem className="h-20 w-20" />
              <div>
                <p className="font-display text-3xl font-black leading-none">SBS</p>
                <p className="label-marche mt-2 text-white/60">Héritage Agricole & Naturel</p>
              </div>
            </div>
            <p className="mt-6 max-w-sm text-[0.95rem] leading-relaxed text-white/70">
              Le SBS est le logiciel personnel de {proprietaire}. Il vend ses récoltes et ses
              animaux, suit ses champs et répond à ses clients — simplement, en français, depuis
              son téléphone.
            </p>
            <a
              href={`https://wa.me/${numero}`}
              target="_blank"
              rel="noreferrer"
              className="mt-6 inline-flex items-center gap-2 rounded-full bg-[#25D366] px-5 py-3 text-sm font-semibold text-[#07321b] transition-transform hover:-translate-y-0.5"
            >
              <MessageCircle className="h-4 w-4" /> Écrire sur WhatsApp
            </a>
          </div>

          <div>
            <p className="label-marche text-white/50">Services</p>
            <ul className="mt-5 space-y-3 text-[0.95rem] text-white/75">
              <li><Link className="lien-souligne hover:text-white" href="/agriculture">Agriculture</Link></li>
              <li><Link className="lien-souligne hover:text-white" href="/elevage">Élevage</Link></li>
              <li><Link className="lien-souligne hover:text-white" href="/produits">Boutique</Link></li>
              <li><Link className="lien-souligne hover:text-white" href="/#offres">Abonnements</Link></li>
            </ul>
          </div>

          <div>
            <p className="label-marche text-white/50">Outils IA</p>
            <ul className="mt-5 space-y-3 text-[0.95rem] text-white/75">
              <li>01 — Météo de mon champ</li>
              <li>02 — Docteur Plante / Animal</li>
              <li>03 — Conseil IA</li>
              <li>04 — Ma Récolte / Mon Élevage</li>
              <li>05 — Quand Arroser / Nourrir</li>
              <li>06 — Mon Score Agricole</li>
            </ul>
          </div>

          <div>
            <p className="label-marche text-white/50">Contact du propriétaire</p>
            <ul className="mt-5 space-y-4 text-[0.95rem] text-white/75">
              <li className="flex items-start gap-3">
                <MessageCircle className="mt-0.5 h-5 w-5 shrink-0 text-[#25D366]" />
                <span>
                  WhatsApp : <span className="tabulaire text-white">{whatsapp}</span>
                  <br />
                  <span className="text-white/50">{proprietaire}</span>
                </span>
              </li>
              <li className="flex items-start gap-3">
                <Mail className="mt-0.5 h-5 w-5 shrink-0 text-mangue" />
                <span>{email}</span>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-mangue" />
                <span>
                  {ville}, {pays}
                </span>
              </li>
              <li className="flex items-center gap-3">
                <IconeFacebook className="h-5 w-5 shrink-0 text-[#1877F2]" />
                <a
                  href="https://facebook.com"
                  target="_blank"
                  rel="noreferrer"
                  className="lien-souligne hover:text-white"
                >
                  Page Facebook SBS
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-14 flex flex-col gap-3 border-t border-white/15 pt-7 text-sm text-white/55 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} SBS — Héritage Agricole et Naturel. Tous droits réservés au propriétaire.</p>
          <p className="tabulaire">
            Payable par Orange Money · MTN MoMo · Wave · Carte Bancaire · Espèces
          </p>
        </div>
      </div>
    </footer>
  );
}
