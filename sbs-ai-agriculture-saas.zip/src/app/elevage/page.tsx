import type { Metadata } from "next";
import Outils from "@/components/Outils";
import { ANIMAUX, fcfa } from "@/lib/data";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

export const metadata: Metadata = {
  title: "Élevage — SBS | Vaches, Chèvres, Moutons, Poulets, Poules pondeuses",
  description:
    "Météo de mon champ, Docteur Animal, Conseil IA, Mon Élevage, Quand Nourrir, Mon Score Agricole : les 6 outils IA du SBS pour les éleveurs du Cameroun et du Tchad.",
};

export default function PageElevage() {
  return (
    <>
      <section className="relative isolate overflow-hidden">
        <div className="absolute inset-0 -z-10">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="images/elevage-zebu.jpg"
            alt=""
            className="h-full w-full object-cover object-[65%_50%]"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-nuit/95 via-nuit/78 to-foret/55" />
        </div>
        <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
          <p className="label-marche text-mangue">Service 02 — Élevage</p>
          <h1 className="mt-6 max-w-4xl font-display text-[clamp(2.6rem,7vw,5.6rem)] font-black leading-[0.95] text-white">
            Votre troupeau a une valeur. <em className="not-italic text-mangue">Voici laquelle.</em>
          </h1>
          <div className="mt-10 flex flex-wrap gap-2">
            {ANIMAUX.map((a) => (
              <span key={a.id} className="rounded-full border border-white/25 px-4 py-2 text-sm text-white/85">
                {a.nom} · <span className="tabulaire">{fcfa(a.prixKg)}</span> / kg
              </span>
            ))}
          </div>
        </div>
      </section>

      <div className="pt-16">
        <Outils service="Élevage" />
      </div>

      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="rounded-[2rem] border border-terre bg-white p-8 sm:p-12">
          <p className="label-marche text-foret">Animaux & valeur du marché</p>
          <h2 className="mt-4 font-display text-3xl font-black text-encre sm:text-4xl">
            Combien vaut votre troupeau aujourd&apos;hui
          </h2>
          <div className="mt-8 overflow-x-auto">
            <table className="w-full min-w-[42rem] text-left">
              <thead>
                <tr className="border-b-2 border-encre/80">
                  <th className="label-marche py-3 text-encre/60">Espèce</th>
                  <th className="label-marche py-3 text-encre/60">Poids moyen</th>
                  <th className="label-marche py-3 text-encre/60">Prix du kilo</th>
                  <th className="label-marche py-3 text-encre/60">Valeur / tête</th>
                  <th className="label-marche py-3 text-encre/60">Gain / jour</th>
                  <th className="label-marche py-3 text-encre/60">Repas</th>
                </tr>
              </thead>
              <tbody>
                {ANIMAUX.map((a) => (
                  <tr key={a.id} className="border-b border-terre">
                    <td className="py-4 font-semibold text-encre">{a.nom}</td>
                    <td className="tabulaire py-4 text-encre/75">{a.poidsKg} kg</td>
                    <td className="tabulaire py-4 text-encre/75">{fcfa(a.prixKg)}</td>
                    <td className="tabulaire py-4 font-semibold text-ocre">{fcfa(a.poidsKg * a.prixKg)}</td>
                    <td className="tabulaire py-4 text-encre/75">{a.gainJourKg} kg</td>
                    <td className="tabulaire py-4 text-encre/75">{a.nourritureJours}× / jour</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Link
            href="/produits"
            className="mt-8 inline-flex items-center gap-2 rounded-full bg-foret px-6 py-3.5 text-sm font-semibold text-white transition-transform hover:-translate-y-0.5"
          >
            Voir les animaux à vendre <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </>
  );
}
