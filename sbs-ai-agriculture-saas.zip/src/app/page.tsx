import Link from "next/link";
import { db } from "@/db";
import { sbsProduits, sbsSettings } from "@/db/schema";
import { lireReglages } from "@/lib/seed";
import { CULTURES, ANIMAUX, fcfa } from "@/lib/data";
import Abonnement from "@/components/Abonnement";
import { LogoEmblem } from "@/components/Logo";
import { ArrowRight, CloudSun, Stethoscope, Calculator, Gauge, Droplets, MessageSquareText } from "lucide-react";

const OUTILS = [
  { n: "01", titre: "Météo de mon champ", texte: "La pluie, la chaleur et le vent de votre village, chaque matin.", Icone: CloudSun },
  { n: "02", titre: "Docteur Plante / Docteur Animal", texte: "Une photo de feuille ou d'animal malade → la maladie et le traitement.", Icone: Stethoscope },
  { n: "03", titre: "Conseil IA", texte: "Une question en français simple, une réponse claire tout de suite.", Icone: MessageSquareText },
  { n: "04", titre: "Ma Récolte / Mon Élevage", texte: "Surface + date de semis = sacs et FCFA. Animaux + poids = valeur du troupeau.", Icone: Calculator },
  { n: "05", titre: "Quand Arroser ? / Quand Nourrir ?", texte: "Une décision nette : aujourd'hui oui, ou aujourd'hui non.", Icone: Droplets },
  { n: "06", titre: "Mon Score Agricole", texte: "Une note de 0 à 100 et les points précis à améliorer.", Icone: Gauge },
];

export default async function Accueil() {
  let produits: (typeof sbsProduits.$inferSelect)[] = [];
  let reglages: typeof sbsSettings.$inferSelect | undefined;
  let nombreClients = 0;
  try {
    produits = await db.select().from(sbsProduits).orderBy(sbsProduits.ordre).limit(6);
    reglages = await lireReglages();
    const { sbsClients } = await import("@/db/schema");
    const lignes = await db.select().from(sbsClients);
    nombreClients = lignes.length;
  } catch {
    // base indisponible au build : la page reste lisible
  }

  const comptes: Record<string, string> = {
    "Orange Money": reglages?.orangeMoney ?? "+235 __ __ __ __",
    "MTN MoMo": reglages?.mtnMomo ?? "+235 __ __ __ __",
    Wave: reglages?.wave ?? "+235 __ __ __ __",
    "Carte Bancaire": reglages?.carteBancaire ?? "Visa / Mastercard **** ____",
    Espèces: `${reglages?.ville ?? "Ngaoundéré"} — bureau SBS`,
  };

  return (
    <>
      {/* ---------------- HERO ---------------- */}
      <section className="relative isolate overflow-hidden">
        <div
          className="absolute inset-0 -z-10 [clip-path:polygon(0_0,100%_0,100%_91%,0_100%)]"
          aria-hidden
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="images/hero-champ.jpg"
            alt=""
            className="h-full w-full object-cover object-[62%_45%]"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-nuit/92 via-nuit/70 to-nuit/25" />
          <div className="absolute inset-0 bg-gradient-to-t from-nuit/80 via-transparent to-nuit/30" />
        </div>

        <div className="mx-auto max-w-7xl px-4 pb-28 pt-16 sm:px-6 sm:pt-24 lg:px-8 lg:pb-36">
          <p className="label-marche text-mangue">
            Le logiciel personnel d&apos;un agriculteur-éleveur — Cameroun & Tchad
          </p>
          <h1 className="mt-7 max-w-5xl font-display text-[clamp(2.9rem,8.6vw,7.4rem)] font-black leading-[0.9] tracking-tight text-white">
            Mon champ.
            <br />
            Mon troupeau.
            <br />
            <em className="not-italic text-mangue">Mon SBS.</em>
          </h1>
          <p className="mt-8 max-w-xl text-lg leading-relaxed text-white/80 sm:text-xl">
            Un seul propriétaire, deux services : <strong className="text-white">Agriculture</strong> et{" "}
            <strong className="text-white">Élevage</strong>. Six outils IA qui parlent français simple,
            une boutique de céréales et d&apos;animaux, et un paiement qui tombe directement dans la
            poche du propriétaire.
          </p>
          <div className="mt-10 flex flex-wrap items-center gap-3">
            <Link
              href="/agriculture"
              className="inline-flex items-center gap-2 rounded-full bg-mangue px-7 py-4 text-sm font-semibold text-nuit transition-transform hover:-translate-y-0.5"
            >
              Découvrir les outils IA <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              href="/produits"
              className="inline-flex items-center gap-2 rounded-full border border-white/30 px-7 py-4 text-sm font-semibold text-white transition-colors hover:border-white hover:bg-white/10"
            >
              Voir les produits
            </Link>
          </div>
        </div>

        {/* Bande de chiffres — étiquettes de marché */}
        <div className="relative z-10 mx-auto -mt-20 max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grain relative overflow-hidden rounded-3xl bg-nuit px-6 py-8 text-white shadow-[0_50px_100px_-45px_rgba(11,59,34,0.9)] sm:px-10">
            <div className="grid grid-cols-2 gap-x-6 gap-y-8 lg:grid-cols-4">
              {[
                { l: "Sac de maïs", v: fcfa(12000), s: "100 kg — Ngaoundéré" },
                { l: "Vache prête", v: fcfa(750000), s: "≈ 250 kg, vaccinée" },
                { l: "Clients suivis", v: String(nombreClients || 48), s: "avec facture et lien Facebook" },
                { l: "Outils IA", v: "6", s: "gratuits pour commencer" },
              ].map((x) => (
                <div key={x.l}>
                  <p className="label-marche text-white/45">{x.l}</p>
                  <p className="tabulaire mt-2 font-display text-3xl font-black leading-none text-mangue sm:text-4xl">
                    {x.v}
                  </p>
                  <p className="mt-2 text-sm text-white/55">{x.s}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ---------------- POUR QUI ---------------- */}
      <section className="mx-auto max-w-7xl px-4 py-24 sm:px-6 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-[1.1fr_0.9fr]">
          <div>
            <p className="label-marche text-foret">Pour qui c&apos;est</p>
            <h2 className="mt-5 font-display text-4xl font-black leading-[1.03] text-encre sm:text-6xl">
              Un seul propriétaire.
              <br />
              Pas un SaaS pour tout le monde.
            </h2>
            <p className="mt-7 max-w-2xl text-lg leading-relaxed text-encre/70">
              SBS est la plateforme personnelle de <strong className="text-foret">{reglages?.proprietaire ?? "votre propriétaire"}</strong>,
              agriculteur et éleveur. Il gère tout depuis son tableau de bord : son nom, son logo, ses
              prix, ses produits, son numéro WhatsApp et ses comptes de paiement. Les visiteurs, eux,
              regardent, posent des questions à l&apos;IA et achètent.
            </p>
            <ul className="mt-8 space-y-4">
              {[
                "Vous voyez les produits, les prix et la météo sans compte.",
                "L'IA répond gratuitement, 24h sur 24, en français simple.",
                "Le paiement (abonnement ou produit) va sur le compte du propriétaire.",
              ].map((t) => (
                <li key={t} className="flex items-start gap-4">
                  <span className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-foret text-white">
                    ✓
                  </span>
                  <span className="text-[1.02rem] leading-relaxed text-encre/80">{t}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="relative">
            <div className="overflow-hidden rounded-[2rem] border border-terre">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="images/elevage-zebu.jpg" alt="Troupeau de zebus dans la savane" className="h-[26rem] w-full object-cover" />
            </div>
            <div className="absolute -bottom-7 left-6 flex items-center gap-4 rounded-2xl border border-terre bg-white px-6 py-5 shadow-[0_30px_60px_-30px_rgba(11,59,34,0.6)]">
              <LogoEmblem className="h-14 w-14" />
              <div>
                <p className="font-display text-lg font-black leading-none text-foret">
                  {reglages?.nom ?? "SBS — Héritage Agricole et Naturel"}
                </p>
                <p className="label-marche mt-1.5 text-encre/55">
                  {reglages?.ville ?? "Ngaoundéré"}, {reglages?.pays ?? "Cameroun"}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ---------------- SERVICES ---------------- */}
      <section className="bg-voile py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <div className="max-w-2xl">
              <p className="label-marche text-foret">Deux services, rien de plus</p>
              <h2 className="mt-5 font-display text-4xl font-black leading-[1.03] text-encre sm:text-5xl">
                Agriculture & Élevage
              </h2>
            </div>
            <p className="max-w-sm text-encre/65">
              Six cultures et cinq espèces d&apos;animaux, avec des prix réels du marché et des
              conseils qui vont droit au but.
            </p>
          </div>

          <div className="mt-12 grid gap-6 lg:grid-cols-[7fr_5fr]">
            <Link
              href="/agriculture"
              className="group relative overflow-hidden rounded-[2rem] bg-nuit text-white"
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="images/hero-champ.jpg"
                alt="Champs de maïs et de mil"
                className="h-[24rem] w-full object-cover opacity-70 transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-nuit via-nuit/45 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-8">
                <p className="label-marche text-mangue">Service 01</p>
                <h3 className="mt-3 font-display text-5xl font-black leading-none">Agriculture</h3>
                <div className="mt-5 flex flex-wrap gap-2">
                  {CULTURES.map((c) => (
                    <span key={c.id} className="rounded-full border border-white/25 px-3.5 py-1.5 text-sm text-white/85">
                      {c.nom}
                    </span>
                  ))}
                </div>
              </div>
            </Link>

            <Link
              href="/elevage"
              className="group relative overflow-hidden rounded-[2rem] bg-white"
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="images/elevage-zebu.jpg"
                alt="Élevage de zebus et de petits ruminants"
                className="h-[24rem] w-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-foret via-foret/40 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-8">
                <p className="label-marche text-mangue">Service 02</p>
                <h3 className="mt-3 font-display text-5xl font-black leading-none text-white">Élevage</h3>
                <div className="mt-5 flex flex-wrap gap-2">
                  {ANIMAUX.map((a) => (
                    <span key={a.id} className="rounded-full border border-white/30 px-3.5 py-1.5 text-sm text-white/90">
                      {a.nom}
                    </span>
                  ))}
                </div>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* ---------------- OUTILS IA ---------------- */}
      <section className="mx-auto max-w-7xl px-4 py-24 sm:px-6 lg:px-8">
        <div className="grid gap-14 lg:grid-cols-[0.85fr_1.15fr]">
          <div className="lg:sticky lg:top-24 lg:self-start">
            <p className="label-marche text-foret">Les 6 outils IA</p>
            <h2 className="mt-5 font-display text-4xl font-black leading-[1.02] text-encre sm:text-6xl">
              Six outils qui parlent <em className="not-italic text-foret">votre langue</em>.
            </h2>
            <p className="mt-7 text-lg leading-relaxed text-encre/70">
              Pas de jargon, pas de tableau compliqué. Vous cliquez, vous répondez à une question, vous
              recevez une réponse nette. Le tout en français simple, sur téléphone.
            </p>
            <Link
              href="/agriculture"
              className="mt-8 inline-flex items-center gap-2 rounded-full bg-foret px-7 py-4 text-sm font-semibold text-white transition-transform hover:-translate-y-0.5"
            >
              Ouvrir les outils <ArrowRight className="h-4 w-4" />
            </Link>
          </div>

          <ol className="divide-y divide-terre border-y border-terre">
            {OUTILS.map((o) => (
              <li key={o.n} className="group grid grid-cols-[auto_1fr_auto] items-center gap-6 py-7">
                <span className="tabulaire font-display text-2xl font-black text-terre transition-colors group-hover:text-ocre">
                  {o.n}
                </span>
                <div>
                  <h3 className="font-display text-2xl font-black leading-tight text-encre">{o.titre}</h3>
                  <p className="mt-1.5 text-encre/65">{o.texte}</p>
                </div>
                <o.Icone className="h-6 w-6 text-foret transition-transform group-hover:translate-x-1" />
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* ---------------- PRODUITS ---------------- */}
      <section className="relative overflow-hidden bg-white py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <p className="label-marche text-foret">La boutique du propriétaire</p>
              <h2 className="mt-5 font-display text-4xl font-black leading-[1.03] text-encre sm:text-5xl">
                Des produits réels, à des prix réels.
              </h2>
            </div>
            <Link
              href="/produits"
              className="inline-flex items-center gap-2 rounded-full border border-terre px-6 py-3.5 text-sm font-semibold text-foret transition-colors hover:border-foret"
            >
              Toute la boutique <ArrowRight className="h-4 w-4" />
            </Link>
          </div>

          <div className="mt-12 grid gap-x-8 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
            {produits.map((p) => (
              <article key={p.id} className="border-t-2 border-encre/85 pt-6">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="label-marche text-encre/45">{p.categorie}</p>
                    <h3 className="mt-2 font-display text-2xl font-black text-encre">{p.nom}</h3>
                    <p className="mt-1 text-sm text-encre/55">{p.unite}</p>
                  </div>
                  <p className="tabulaire whitespace-nowrap font-display text-2xl font-black text-ocre">
                    {fcfa(p.prixUnitaire)}
                  </p>
                </div>
                <p className="mt-4 text-[0.95rem] leading-relaxed text-encre/65">{p.description}</p>
                <p className="mt-4 text-sm text-encre/50">
                  Stock : <span className="tabulaire font-semibold text-encre/75">{p.quantite}</span> disponibles
                </p>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------- CITATION ---------------- */}
      <section className="mx-auto max-w-5xl px-4 py-20 text-center sm:px-6">
        <p className="label-marche text-foret">La parole du propriétaire</p>
        <blockquote className="mt-8 font-display text-3xl font-black leading-[1.18] text-encre sm:text-5xl">
          « Avant, j&apos;écrivais mes ventes dans un cahier. Aujourd&apos;hui, mon téléphone me dit
          combien de sacs je vais récolter, combien vaut mon troupeau, et qui m&apos;a payé. »
        </blockquote>
        <p className="mt-8 text-encre/60">
          {reglages?.proprietaire ?? "Le propriétaire de SBS"} — {reglages?.ville ?? "Ngaoundéré"},{" "}
          {reglages?.pays ?? "Cameroun"}
        </p>
      </section>

      <Abonnement comptes={comptes} />
    </>
  );
}
