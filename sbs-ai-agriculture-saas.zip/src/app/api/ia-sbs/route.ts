import { NextResponse } from "next/server";
import { db } from "@/db";
import { sbsIaConversations } from "@/db/schema";
import { repondreIA } from "@/lib/ia";
import { lireReglages } from "@/lib/seed";
import { desc } from "drizzle-orm";

export const runtime = "nodejs";

/** IA guide SBS — 100 % gratuite, accessible à tous, même sans abonnement. */
export async function POST(request: Request) {
  try {
    const corps = (await request.json()) as { question?: string; message?: string };
    const question = (corps.question ?? corps.message ?? "").toString().slice(0, 600);
    const reglages = await lireReglages();
    const reponse = repondreIA(question, {
      whatsapp: reglages?.whatsapp ?? "+235 66 00 00 00",
      proprietaire: reglages?.proprietaire ?? "le propriétaire de SBS",
    });

    try {
      await db
        .insert(sbsIaConversations)
        .values({ question, reponse })
        .returning({ id: sbsIaConversations.id });
    } catch (e) {
      console.error("SBS: sauvegarde conversation IA", e);
    }

    return NextResponse.json({ question, reponse, gratuite: true });
  } catch {
    return NextResponse.json(
      {
        reponse:
          "Le service est un moment occupé. Clique sur le bouton vert WhatsApp pour parler au propriétaire de SBS.",
      },
      { status: 200 },
    );
  }
}

export async function GET() {
  try {
    const conversations = await db
      .select()
      .from(sbsIaConversations)
      .orderBy(desc(sbsIaConversations.date))
      .limit(50);
    return NextResponse.json({ conversations });
  } catch {
    return NextResponse.json({ conversations: [] });
  }
}
