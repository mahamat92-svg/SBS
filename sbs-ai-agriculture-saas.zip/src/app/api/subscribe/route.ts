import { NextResponse } from "next/server";
import { db } from "@/db";
import { sbsClients, sbsPaiements, sbsSettings } from "@/db/schema";
import { lireReglages } from "@/lib/seed";
import { eq } from "drizzle-orm";

export const runtime = "nodejs";

/**
 * Paiement d'abonnement.
 * L'argent est crédité DIRECTEMENT sur les comptes du propriétaire de SBS
 * (Orange Money / MTN MoMo / Wave / Carte Bancaire / Espèces) — jamais sur
 * le compte du développeur.
 */
export async function POST(request: Request) {
  try {
    const corps = await request.json();
    const nom = String(corps.nom ?? "").slice(0, 120) || "Client SBS";
    const telephone = String(corps.telephone ?? "").slice(0, 40);
    const village = String(corps.village ?? "").slice(0, 80);
    const service = corps.service === "Élevage" ? "Élevage" : "Agriculture";
    const lienFacebook = String(corps.lienFacebook ?? "").slice(0, 300);
    const offre = String(corps.offre ?? "Pro").slice(0, 40);
    const methode = String(corps.methode ?? "Orange Money").slice(0, 40);
    const montant = Math.max(0, Math.round(Number(corps.montant ?? 0)));

    const reglages = await lireReglages();
    if (!reglages) {
      return NextResponse.json({ erreur: "Réglages introuvables" }, { status: 500 });
    }

    // 1. Création / mise à jour du client
    const existant = telephone
      ? await db.select().from(sbsClients).where(eq(sbsClients.telephone, telephone)).limit(1)
      : [];
    let clientId: number;
    if (existant[0]) {
      const maj = await db
        .update(sbsClients)
        .set({
          nom,
          village,
          service,
          offre,
          lienFacebook: lienFacebook || existant[0].lienFacebook,
          soldeMobileMoney: existant[0].soldeMobileMoney + montant,
        })
        .where(eq(sbsClients.id, existant[0].id))
        .returning({ id: sbsClients.id });
      clientId = maj[0].id;
    } else {
      const insere = await db
        .insert(sbsClients)
        .values({ nom, telephone, village, service, offre, lienFacebook, soldeMobileMoney: montant })
        .returning({ id: sbsClients.id });
      clientId = insere[0].id;
    }

    // 2. Enregistrement du paiement
    const reference =
      "SBS-" + Date.now().toString(36).toUpperCase() + "-" + Math.floor(Math.random() * 900 + 100);
    await db.insert(sbsPaiements).values({
      clientNom: nom,
      telephone,
      offre,
      montant,
      methode,
      reference,
      statut: "Payé",
    });

    // 3. Le solde DU PROPRIÉTAIRE augmente automatiquement
    if (methode === "Carte Bancaire") {
      await db
        .update(sbsSettings)
        .set({ soldeCarteBancaire: reglages.soldeCarteBancaire + montant, updatedAt: new Date() })
        .where(eq(sbsSettings.id, "principal"));
    } else if (methode === "Espèces") {
      await db
        .update(sbsSettings)
        .set({ soldeEspeces: reglages.soldeEspeces + montant, updatedAt: new Date() })
        .where(eq(sbsSettings.id, "principal"));
    } else {
      await db
        .update(sbsSettings)
        .set({ soldeMobileMoney: reglages.soldeMobileMoney + montant, updatedAt: new Date() })
        .where(eq(sbsSettings.id, "principal"));
    }

    const numero =
      methode === "Carte Bancaire"
        ? reglages.carteBancaire
        : methode === "MTN MoMo"
          ? reglages.mtnMomo
          : methode === "Wave"
            ? reglages.wave
            : reglages.orangeMoney;

    return NextResponse.json({
      message: `Paiement de ${montant.toLocaleString("fr-FR")} FCFA reçu par ${reglages.proprietaire}. Référence ${reference}.`,
      reference,
      clientId,
      compteProprietaire: numero,
      methode,
    });
  } catch (e) {
    return NextResponse.json(
      { erreur: e instanceof Error ? e.message : "Erreur serveur" },
      { status: 500 },
    );
  }
}

export async function GET() {
  try {
    const reglages = await lireReglages();
    return NextResponse.json({
      comptes: {
        "Orange Money": reglages?.orangeMoney,
        "MTN MoMo": reglages?.mtnMomo,
        Wave: reglages?.wave,
        "Carte Bancaire": reglages?.carteBancaire,
        "Nom de la banque": reglages?.nomBanque,
        "Espèces": `${reglages?.ville} — bureau SBS`,
      },
    });
  } catch {
    return NextResponse.json({ comptes: {} });
  }
}
