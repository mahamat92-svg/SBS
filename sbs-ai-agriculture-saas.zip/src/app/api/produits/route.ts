import { NextResponse } from "next/server";
import { db } from "@/db";
import { sbsProduits } from "@/db/schema";
import { eq } from "drizzle-orm";

export const runtime = "nodejs";

export async function GET() {
  try {
    const produits = await db.select().from(sbsProduits).orderBy(sbsProduits.ordre);
    return NextResponse.json({ produits });
  } catch {
    return NextResponse.json({ produits: [] });
  }
}

export async function PATCH(request: Request) {
  try {
    const corps = await request.json();
    const id = Number(corps.id);
    if (!Number.isFinite(id)) {
      return NextResponse.json({ erreur: "Identifiant manquant" }, { status: 400 });
    }
    const maj: Record<string, string | number | boolean> = {};
    for (const champ of ["nom", "unite", "description", "categorie"] as const) {
      if (typeof corps[champ] === "string") maj[champ] = corps[champ].slice(0, 300);
    }
    for (const champ of ["prixUnitaire", "quantite"] as const) {
      if (corps[champ] !== undefined) maj[champ] = Math.max(0, Math.round(Number(corps[champ])));
    }
    if (typeof corps.disponible === "boolean") maj["disponible"] = corps.disponible;
    const lignes = await db.update(sbsProduits).set(maj).where(eq(sbsProduits.id, id)).returning();
    return NextResponse.json({ produit: lignes[0] });
  } catch (e) {
    return NextResponse.json(
      { erreur: e instanceof Error ? e.message : "Erreur serveur" },
      { status: 500 },
    );
  }
}
