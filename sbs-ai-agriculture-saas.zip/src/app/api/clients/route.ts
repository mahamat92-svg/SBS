import { NextResponse } from "next/server";
import { db } from "@/db";
import { sbsClients } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const runtime = "nodejs";

export async function GET() {
  try {
    const clients = await db.select().from(sbsClients).orderBy(desc(sbsClients.date)).limit(200);
    return NextResponse.json({ clients });
  } catch {
    return NextResponse.json({ clients: [] });
  }
}

export async function POST(request: Request) {
  try {
    const corps = await request.json();
    const valeurs = {
      nom: String(corps.nom ?? "Client").slice(0, 120),
      telephone: String(corps.telephone ?? "").slice(0, 40),
      village: String(corps.village ?? "").slice(0, 80),
      service: corps.service === "Élevage" ? "Élevage" : "Agriculture",
      lienFacebook: String(corps.lienFacebook ?? "").slice(0, 300),
      offre: String(corps.offre ?? "Gratuit 7 jours").slice(0, 40),
      soldeMobileMoney: Math.max(0, Math.round(Number(corps.soldeMobileMoney ?? 0))),
      soldeCarteBancaire: Math.max(0, Math.round(Number(corps.soldeCarteBancaire ?? 0))),
    };
    const lignes = await db.insert(sbsClients).values(valeurs).returning();
    return NextResponse.json({ client: lignes[0] });
  } catch (e) {
    return NextResponse.json(
      { erreur: e instanceof Error ? e.message : "Erreur serveur" },
      { status: 500 },
    );
  }
}

export async function PATCH(request: Request) {
  try {
    const corps = await request.json();
    const id = Number(corps.id);
    if (!Number.isFinite(id)) {
      return NextResponse.json({ erreur: "Identifiant manquant" }, { status: 400 });
    }
    const maj: Record<string, string | number> = {};
    for (const champ of ["nom", "telephone", "village", "service", "lienFacebook", "offre"] as const) {
      if (typeof corps[champ] === "string") maj[champ] = corps[champ].slice(0, 300);
    }
    for (const champ of ["soldeMobileMoney", "soldeCarteBancaire"] as const) {
      if (corps[champ] !== undefined) maj[champ] = Math.max(0, Math.round(Number(corps[champ])));
    }
    const lignes = await db.update(sbsClients).set(maj).where(eq(sbsClients.id, id)).returning();
    return NextResponse.json({ client: lignes[0] });
  } catch (e) {
    return NextResponse.json(
      { erreur: e instanceof Error ? e.message : "Erreur serveur" },
      { status: 500 },
    );
  }
}
