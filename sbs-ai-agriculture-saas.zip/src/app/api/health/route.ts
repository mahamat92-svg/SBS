import { NextResponse } from "next/server";
import { db } from "@/db";
import { sbsSettings } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const rows = await db
      .select({ ok: sbsSettings.id })
      .from(sbsSettings)
      .where(eq(sbsSettings.id, "principal"))
      .limit(1);
    return NextResponse.json({
      status: "ok",
      service: "SBS — Héritage Agricole et Naturel",
      database: rows.length > 0 ? "connectée" : "en attente",
      time: new Date().toISOString(),
    });
  } catch (e) {
    // Le service reste joignable même si la base n'est pas encore prête.
    return NextResponse.json({
      status: "degraded",
      service: "SBS — Héritage Agricole et Naturel",
      database: e instanceof Error ? e.message : "inconnue",
      time: new Date().toISOString(),
    });
  }
}
