import { NextResponse } from "next/server";
import { db } from "@/db";
import { sbsFactures } from "@/db/schema";
import { desc } from "drizzle-orm";

export const runtime = "nodejs";

export type LigneFacture = {
  id: number;
  produit: string;
  quantite: number;
  prixUnitaire: number;
};

export async function GET() {
  try {
    const factures = await db.select().from(sbsFactures).orderBy(desc(sbsFactures.date)).limit(50);
    return NextResponse.json({ factures });
  } catch {
    return NextResponse.json({ factures: [] });
  }
}

export async function POST(request: Request) {
  try {
    const corps = await request.json();
    const lignes: LigneFacture[] = Array.isArray(corps.lignes) ? corps.lignes : [];
    const sousTotal = lignes.reduce(
      (s, l) => s + Math.round(Number(l.quantite) * Number(l.prixUnitaire)),
      0,
    );
    const remise = Math.max(0, Math.round(Number(corps.remise ?? 0)));
    const base = Math.max(0, sousTotal - remise);
    const tva = Math.round(base * (Math.max(0, Number(corps.tauxTva ?? 19.25)) / 100));
    const total = base + tva;

    const reference =
      "FAC-" + new Date().getFullYear() + "-" + Math.floor(Math.random() * 9000 + 1000);

    const lignesInserees = await db
      .insert(sbsFactures)
      .values({
        reference,
        clientNom: String(corps.clientNom ?? "Client comptoir").slice(0, 120),
        lignes: lignes.map((l) => ({
          produit: String(l.produit).slice(0, 120),
          quantite: Math.max(0, Number(l.quantite) || 0),
          prixUnitaire: Math.max(0, Math.round(Number(l.prixUnitaire) || 0)),
        })),
        sousTotal,
        remise,
        tva,
        total,
        statut: String(corps.statut ?? "En attente").slice(0, 40),
      })
      .returning();

    return NextResponse.json({ facture: lignesInserees[0], sousTotal, remise, tva, total });
  } catch (e) {
    return NextResponse.json(
      { erreur: e instanceof Error ? e.message : "Erreur serveur" },
      { status: 500 },
    );
  }
}
