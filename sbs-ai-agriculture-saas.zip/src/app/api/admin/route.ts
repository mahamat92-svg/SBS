import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  sbsClients,
  sbsFactures,
  sbsIaConversations,
  sbsPaiements,
  sbsSettings,
} from "@/db/schema";
import { lireReglages } from "@/lib/seed";
import { desc, eq, sql } from "drizzle-orm";

export const runtime = "nodejs";

const CHAMPS_MODIFIABLES = [
  "nom",
  "slogan",
  "proprietaire",
  "logoUrl",
  "whatsapp",
  "email",
  "ville",
  "pays",
  "orangeMoney",
  "mtnMomo",
  "wave",
  "carteBancaire",
  "nomBanque",
] as const;

export async function GET() {
  try {
    const reglages = await lireReglages();
    const paiements = await db
      .select()
      .from(sbsPaiements)
      .orderBy(desc(sbsPaiements.date))
      .limit(30);
    const clients = await db.select().from(sbsClients).orderBy(desc(sbsClients.date)).limit(100);
    const factures = await db
      .select()
      .from(sbsFactures)
      .orderBy(desc(sbsFactures.date))
      .limit(30);
    const conversations = await db
      .select()
      .from(sbsIaConversations)
      .orderBy(desc(sbsIaConversations.date))
      .limit(30);
    const [totalClients] = await db.select({ n: sql<number>`count(*)` }).from(sbsClients);
    const [totalPaiements] = await db.select({ n: sql<number>`coalesce(sum(${sbsPaiements.montant}),0)` }).from(sbsPaiements);

    return NextResponse.json({
      reglages,
      paiements,
      clients,
      factures,
      conversations,
      statistiques: {
        nombreClients: Number(totalClients?.n ?? 0),
        totalEncaisse: Number(totalPaiements?.n ?? 0),
        soldeTotal:
          (reglages?.soldeMobileMoney ?? 0) +
          (reglages?.soldeCarteBancaire ?? 0) +
          (reglages?.soldeEspeces ?? 0),
      },
    });
  } catch (e) {
    return NextResponse.json(
      { erreur: e instanceof Error ? e.message : "Erreur serveur" },
      { status: 500 },
    );
  }
}

export async function POST(request: Request) {
  try {
    const corps = await request.json();
    await lireReglages();
    const miseAJour: Record<string, string> = {};
    for (const champ of CHAMPS_MODIFIABLES) {
      if (typeof corps[champ] === "string") miseAJour[champ] = corps[champ].slice(0, 200);
    }
    miseAJour["updatedAt"] = new Date().toISOString();
    const lignes = await db
      .update(sbsSettings)
      .set(miseAJour)
      .where(eq(sbsSettings.id, "principal"))
      .returning();
    return NextResponse.json({ reglages: lignes[0], message: "Réglages enregistrés." });
  } catch (e) {
    return NextResponse.json(
      { erreur: e instanceof Error ? e.message : "Erreur serveur" },
      { status: 500 },
    );
  }
}
