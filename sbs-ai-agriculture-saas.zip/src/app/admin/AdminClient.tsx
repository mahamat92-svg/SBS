"use client";

import { useState } from "react";
import type {
  SbsClient,
  SbsFacture,
  SbsIaConversation,
  SbsPaiement,
  SbsProduit,
  SbsSettings,
} from "@/db/schema";
import {
  LayoutDashboard,
  UserRound,
  Wallet,
  Users,
  Sheet,
  Package,
  MessagesSquare,
  Check,
  Loader2,
  ExternalLink,
  RefreshCw,
} from "lucide-react";
import { IconeFacebook } from "@/components/IconeFacebook";
import LogoProprietaire from "@/components/LogoProprietaire";
import TableauExcel from "@/components/TableauExcel";
import { fcfa } from "@/lib/data";

type Onglet = "bord" | "profil" | "comptes" | "clients" | "facture" | "produits" | "ia";

const ONGLETS: { id: Onglet; label: string; Icone: typeof LayoutDashboard }[] = [
  { id: "bord", label: "Tableau de bord", Icone: LayoutDashboard },
  { id: "profil", label: "Mon profil & logo", Icone: UserRound },
  { id: "comptes", label: "Mes comptes de paiement", Icone: Wallet },
  { id: "clients", label: "Mes clients", Icone: Users },
  { id: "facture", label: "Tableau Excel", Icone: Sheet },
  { id: "produits", label: "Mes produits", Icone: Package },
  { id: "ia", label: "Messages de l'IA", Icone: MessagesSquare },
];

function Champ({
  label,
  valeur,
  onChange,
  aide,
  type = "text",
}: {
  label: string;
  valeur: string;
  onChange: (v: string) => void;
  aide?: string;
  type?: string;
}) {
  return (
    <label className="block">
      <span className="label-marche text-encre/55">{label}</span>
      <input
        type={type}
        value={valeur}
        onChange={(e) => onChange(e.target.value)}
        className="mt-2 w-full rounded-xl border border-terre bg-white px-4 py-3 outline-none transition-colors focus:border-foret"
      />
      {aide && <span className="mt-1.5 block text-xs text-encre/50">{aide}</span>}
    </label>
  );
}

export default function AdminClient({
  reglages: reglagesInitiaux,
  paiementsInitiaux,
  clientsInitiaux,
  facturesInitiales,
  conversationsInitiales,
  produitsInitiaux,
  totalEncaisse,
}: {
  reglages: SbsSettings;
  paiementsInitiaux: SbsPaiement[];
  clientsInitiaux: SbsClient[];
  facturesInitiales: SbsFacture[];
  conversationsInitiales: SbsIaConversation[];
  produitsInitiaux: SbsProduit[];
  totalEncaisse: number;
}) {
  const [onglet, setOnglet] = useState<Onglet>("bord");
  const [reglages, setReglages] = useState<SbsSettings>(reglagesInitiaux);
  const [clients, setClients] = useState<SbsClient[]>(clientsInitiaux);
  const [produits, setProduits] = useState<SbsProduit[]>(produitsInitiaux);
  const [enCours, setEnCours] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const soldeTotal =
    reglages.soldeMobileMoney + reglages.soldeCarteBancaire + reglages.soldeEspeces;

  function maj(champ: keyof SbsSettings, valeur: string) {
    setReglages((r) => ({ ...r, [champ]: valeur }) as SbsSettings);
  }

  async function enregistrerProfil(comptes = false) {
    setEnCours(true);
    setMessage(null);
    try {
      const rep = await fetch("/api/admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(
          comptes
            ? {
                orangeMoney: reglages.orangeMoney,
                mtnMomo: reglages.mtnMomo,
                wave: reglages.wave,
                carteBancaire: reglages.carteBancaire,
                nomBanque: reglages.nomBanque,
              }
            : {
                nom: reglages.nom,
                slogan: reglages.slogan,
                proprietaire: reglages.proprietaire,
                logoUrl: reglages.logoUrl,
                whatsapp: reglages.whatsapp,
                email: reglages.email,
                ville: reglages.ville,
                pays: reglages.pays,
              },
        ),
      });
      const d = (await rep.json()) as { message?: string; erreur?: string };
      setMessage(d.erreur ?? d.message ?? "Réglages enregistrés.");
    } catch {
      setMessage("Enregistrement impossible pour le moment.");
    } finally {
      setEnCours(false);
    }
  }

  async function majClient(id: number, patch: Partial<SbsClient>) {
    setClients((cs) => cs.map((c) => (c.id === id ? { ...c, ...patch } : c)));
    try {
      await fetch("/api/clients", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, ...patch }),
      });
    } catch {
      setMessage("Mise à jour du client impossible.");
    }
  }

  async function majProduit(id: number, patch: Partial<SbsProduit>) {
    setProduits((ps) => ps.map((p) => (p.id === id ? { ...p, ...patch } : p)));
    try {
      await fetch("/api/produits", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, ...patch }),
      });
    } catch {
      setMessage("Mise à jour du produit impossible.");
    }
  }

  return (
    <div className="mx-auto max-w-[100rem] px-4 pb-16 pt-10 sm:px-6 lg:px-8">
      {/* En-tête */}
      <div className="flex flex-wrap items-end justify-between gap-6">
        <div>
          <p className="label-marche text-foret">Espace réservé au propriétaire</p>
          <h1 className="mt-3 font-display text-4xl font-black leading-none text-encre sm:text-6xl">
            Dashboard SBS
          </h1>
          <p className="mt-3 text-encre/65">
            {reglages.proprietaire} — {reglages.ville}, {reglages.pays}
          </p>
        </div>
        <button
          type="button"
          onClick={() => window.location.reload()}
          className="inline-flex items-center gap-2 rounded-full border border-terre px-5 py-3 text-sm font-semibold text-encre/70 transition-colors hover:border-foret hover:text-foret"
        >
          <RefreshCw className="h-4 w-4" /> Actualiser les soldes
        </button>
      </div>

      {/* Bandeau solde */}
      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { l: "Solde Total", v: soldeTotal, couleur: "bg-nuit text-white", detail: "toutes méthodes confondues" },
          {
            l: "Solde Mobile Money",
            v: reglages.soldeMobileMoney,
            couleur: "bg-white border border-terre text-encre",
            detail: "Orange Money + MTN MoMo + Wave",
          },
          {
            l: "Solde Carte Bancaire",
            v: reglages.soldeCarteBancaire,
            couleur: "bg-white border border-terre text-encre",
            detail: reglages.carteBancaire,
          },
          {
            l: "Solde Espèces",
            v: reglages.soldeEspeces,
            couleur: "bg-white border border-terre text-encre",
            detail: `encaissé au bureau de ${reglages.ville}`,
          },
        ].map((s) => (
          <div key={s.l} className={`rounded-3xl p-6 ${s.couleur}`}>
            <p className={`label-marche ${s.couleur.includes("bg-nuit") ? "text-white/55" : "text-encre/50"}`}>
              {s.l}
            </p>
            <p
              className={`tabulaire mt-3 font-display text-3xl font-black leading-none sm:text-4xl ${
                s.couleur.includes("bg-nuit") ? "text-mangue" : "text-ocre"
              }`}
            >
              {fcfa(s.v)}
            </p>
            <p className={`mt-2 text-xs ${s.couleur.includes("bg-nuit") ? "text-white/55" : "text-encre/50"}`}>
              {s.detail}
            </p>
          </div>
        ))}
      </div>

      {/* Onglets */}
      <div className="mt-10 grid gap-8 lg:grid-cols-[17rem_1fr]">
        <aside className="lg:sticky lg:top-24 lg:self-start">
          <nav className="flex gap-2 overflow-x-auto pb-2 lg:flex-col lg:overflow-visible lg:pb-0">
            {ONGLETS.map((o) => (
              <button
                key={o.id}
                type="button"
                onClick={() => setOnglet(o.id)}
                className={`flex shrink-0 items-center gap-3 rounded-2xl border px-4 py-3 text-left text-sm font-semibold transition-colors ${
                  onglet === o.id
                    ? "border-foret bg-foret text-white"
                    : "border-terre bg-white text-encre/75 hover:border-foret/50"
                }`}
              >
                <o.Icone className="h-4 w-4" />
                {o.label}
              </button>
            ))}
          </nav>
          {message && (
            <p className="mt-4 rounded-2xl bg-[#eef6f0] px-4 py-3 text-sm text-foret">{message}</p>
          )}
        </aside>

        <div className="min-w-0">
          {/* TABLEAU DE BORD */}
          {onglet === "bord" && (
            <div className="rounded-[2rem] border border-terre bg-white p-6 sm:p-9">
              <h2 className="font-display text-3xl font-black text-encre">Tableau de bord</h2>
              <p className="mt-2 text-encre/65">
                Total encaissé depuis l&apos;ouverture :{" "}
                <span className="tabulaire font-semibold text-foret">{fcfa(totalEncaisse)}</span> —{" "}
                {clients.length} client(s) enregistré(s).
              </p>
              <div className="mt-8 overflow-x-auto">
                <table className="w-full min-w-[42rem] text-left">
                  <thead>
                    <tr className="border-b-2 border-encre/80">
                      <th className="label-marche py-3 text-encre/60">Date</th>
                      <th className="label-marche py-3 text-encre/60">Client</th>
                      <th className="label-marche py-3 text-encre/60">Offre</th>
                      <th className="label-marche py-3 text-encre/60">Méthode</th>
                      <th className="label-marche py-3 text-encre/60">Référence</th>
                      <th className="label-marche py-3 text-right text-encre/60">Montant</th>
                    </tr>
                  </thead>
                  <tbody>
                    {paiementsInitiaux.length === 0 && (
                      <tr>
                        <td colSpan={6} className="py-8 text-center text-encre/50">
                          Aucun paiement pour le moment. Partagez votre lien d&apos;abonnement.
                        </td>
                      </tr>
                    )}
                    {paiementsInitiaux.map((p) => (
                      <tr key={p.id} className="border-b border-terre">
                        <td className="tabulaire py-4 text-encre/70">
                          {new Date(p.date).toLocaleDateString("fr-FR")}
                        </td>
                        <td className="py-4 font-semibold text-encre">{p.clientNom}</td>
                        <td className="py-4 text-encre/70">{p.offre}</td>
                        <td className="py-4 text-encre/70">{p.methode}</td>
                        <td className="tabulaire py-4 text-encre/55">{p.reference}</td>
                        <td className="tabulaire py-4 text-right font-display text-lg font-black text-ocre">
                          {fcfa(p.montant)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <h3 className="mt-10 font-display text-2xl font-black text-encre">Dernières factures</h3>
              <div className="mt-4 overflow-x-auto">
                <table className="w-full min-w-[38rem] text-left">
                  <thead>
                    <tr className="border-b-2 border-encre/80">
                      <th className="label-marche py-3 text-encre/60">Référence</th>
                      <th className="label-marche py-3 text-encre/60">Client</th>
                      <th className="label-marche py-3 text-encre/60">Statut</th>
                      <th className="label-marche py-3 text-right text-encre/60">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {facturesInitiales.length === 0 && (
                      <tr>
                        <td colSpan={4} className="py-8 text-center text-encre/50">
                          Aucune facture enregistrée. Ouvrez l&apos;onglet « Tableau Excel ».
                        </td>
                      </tr>
                    )}
                    {facturesInitiales.map((f) => (
                      <tr key={f.id} className="border-b border-terre">
                        <td className="tabulaire py-4 text-encre/70">{f.reference}</td>
                        <td className="py-4 font-semibold text-encre">{f.clientNom}</td>
                        <td className="py-4 text-encre/70">{f.statut}</td>
                        <td className="tabulaire py-4 text-right font-display text-lg font-black text-ocre">
                          {fcfa(f.total)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* PROFIL */}
          {onglet === "profil" && (
            <div className="rounded-[2rem] border border-terre bg-white p-6 sm:p-9">
              <h2 className="font-display text-3xl font-black text-encre">Mon profil & mon logo</h2>
              <p className="mt-2 text-encre/65">
                Ces informations s&apos;affichent dans le pied de page, la page contact et dans les
                réponses de l&apos;IA.
              </p>
              <div className="mt-8 grid gap-5 sm:grid-cols-2">
                <Champ label="Nom du SaaS" valeur={reglages.nom} onChange={(v) => maj("nom", v)} />
                <Champ label="Slogan" valeur={reglages.slogan} onChange={(v) => maj("slogan", v)} />
                <Champ label="Mon nom" valeur={reglages.proprietaire} onChange={(v) => maj("proprietaire", v)} />
                <Champ
                  label="Mon numéro WhatsApp"
                  valeur={reglages.whatsapp}
                  onChange={(v) => maj("whatsapp", v)}
                  aide="Ce numéro s'affiche partout : bouton flottant, footer, contact et IA."
                />
                <Champ label="Mon e-mail" valeur={reglages.email} onChange={(v) => maj("email", v)} />
                <Champ
                  label="URL de mon logo"
                  valeur={reglages.logoUrl}
                  onChange={(v) => maj("logoUrl", v)}
                  aide="Laissez l'adresse du logo SBS si vous n'avez pas encore le vôtre."
                />
                <Champ label="Ma ville" valeur={reglages.ville} onChange={(v) => maj("ville", v)} />
                <Champ label="Mon pays" valeur={reglages.pays} onChange={(v) => maj("pays", v)} />
              </div>

              <div className="mt-6 flex items-center gap-5 rounded-2xl border border-terre bg-voile p-5">
                <LogoProprietaire src={reglages.logoUrl} className="h-20 w-20" />
                <div>
                  <p className="label-marche text-encre/55">Aperçu de mon logo</p>
                  <p className="mt-1.5 text-sm leading-relaxed text-encre/70">
                    Déposez votre image dans <code className="rounded bg-white px-1.5 py-0.5">public/images/</code>{" "}
                    puis collez son adresse ci-dessus. Si l&apos;image est absente, le logo SBS est
                    utilisé automatiquement.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => enregistrerProfil(false)}
                disabled={enCours}
                className="mt-8 inline-flex items-center gap-2 rounded-full bg-foret px-7 py-3.5 text-sm font-semibold text-white transition-transform hover:-translate-y-0.5 disabled:opacity-60"
              >
                {enCours ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
                Enregistrer mes informations
              </button>
            </div>
          )}

          {/* COMPTES */}
          {onglet === "comptes" && (
            <div className="rounded-[2rem] border border-terre bg-white p-6 sm:p-9">
              <h2 className="font-display text-3xl font-black text-encre">Mes comptes de paiement</h2>
              <p className="mt-2 max-w-2xl text-encre/65">
                Quand un client paie son abonnement, l&apos;argent va <strong className="text-foret">directement</strong>{" "}
                sur ces comptes, à vous. Aucun intermédiaire, aucun compte développeur.
              </p>
              <div className="mt-8 grid gap-5 sm:grid-cols-2">
                <Champ
                  label="Mon Orange Money"
                  valeur={reglages.orangeMoney}
                  onChange={(v) => maj("orangeMoney", v)}
                  aide="Exemple : +235 66 00 00 00"
                />
                <Champ
                  label="Mon MTN MoMo"
                  valeur={reglages.mtnMomo}
                  onChange={(v) => maj("mtnMomo", v)}
                  aide="Exemple : +235 66 00 00 00"
                />
                <Champ label="Mon Wave" valeur={reglages.wave} onChange={(v) => maj("wave", v)} />
                <Champ
                  label="Ma Carte Bancaire"
                  valeur={reglages.carteBancaire}
                  onChange={(v) => maj("carteBancaire", v)}
                  aide="Exemple : Visa / Mastercard **** 1234"
                />
                <Champ label="Nom de ma banque" valeur={reglages.nomBanque} onChange={(v) => maj("nomBanque", v)} />
              </div>
              <button
                type="button"
                onClick={() => enregistrerProfil(true)}
                disabled={enCours}
                className="mt-8 inline-flex items-center gap-2 rounded-full bg-foret px-7 py-3.5 text-sm font-semibold text-white transition-transform hover:-translate-y-0.5 disabled:opacity-60"
              >
                {enCours ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
                Enregistrer mes comptes
              </button>
            </div>
          )}

          {/* CLIENTS */}
          {onglet === "clients" && (
            <div className="rounded-[2rem] border border-terre bg-white p-6 sm:p-9">
              <h2 className="font-display text-3xl font-black text-encre">Mes clients</h2>
              <p className="mt-2 text-encre/65">
                Chaque client a son lien Facebook, son solde Mobile Money et son solde Carte
                Bancaire. Modifiez un montant : c&apos;est enregistré tout de suite.
              </p>
              <div className="mt-8 overflow-x-auto">
                <table className="w-full min-w-[58rem] text-left">
                  <thead>
                    <tr className="border-b-2 border-encre/80">
                      <th className="label-marche py-3 text-encre/60">Client</th>
                      <th className="label-marche py-3 text-encre/60">Téléphone</th>
                      <th className="label-marche py-3 text-encre/60">Village</th>
                      <th className="label-marche py-3 text-encre/60">Facebook</th>
                      <th className="label-marche py-3 text-encre/60">Solde Mobile Money</th>
                      <th className="label-marche py-3 text-encre/60">Solde Carte</th>
                      <th className="label-marche py-3 text-right text-encre/60">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {clients.length === 0 && (
                      <tr>
                        <td colSpan={7} className="py-10 text-center text-encre/50">
                          Aucun client pour le moment.
                        </td>
                      </tr>
                    )}
                    {clients.map((c) => (
                      <tr key={c.id} className="border-b border-terre align-middle">
                        <td className="py-3 font-semibold text-encre">{c.nom}</td>
                        <td className="tabulaire py-3 text-encre/70">{c.telephone}</td>
                        <td className="py-3 text-encre/70">{c.village}</td>
                        <td className="py-3">
                          {c.lienFacebook ? (
                            <a
                              href={c.lienFacebook}
                              target="_blank"
                              rel="noreferrer"
                              className="inline-flex items-center gap-2 text-[#1877F2] hover:underline"
                              aria-label={`Facebook de ${c.nom}`}
                            >
                              <IconeFacebook className="h-5 w-5" />
                              <ExternalLink className="h-3.5 w-3.5" />
                            </a>
                          ) : (
                            <span className="text-xs text-encre/35">sans lien</span>
                          )}
                        </td>
                        <td className="py-3">
                          <input
                            type="number"
                            value={c.soldeMobileMoney}
                            onChange={(e) =>
                              majClient(c.id, { soldeMobileMoney: Math.max(0, Number(e.target.value) || 0) })
                            }
                            className="tabulaire w-36 rounded-lg border border-terre px-3 py-2 outline-none focus:border-foret"
                          />
                        </td>
                        <td className="py-3">
                          <input
                            type="number"
                            value={c.soldeCarteBancaire}
                            onChange={(e) =>
                              majClient(c.id, { soldeCarteBancaire: Math.max(0, Number(e.target.value) || 0) })
                            }
                            className="tabulaire w-36 rounded-lg border border-terre px-3 py-2 outline-none focus:border-foret"
                          />
                        </td>
                        <td className="tabulaire py-3 text-right font-display text-lg font-black text-ocre">
                          {fcfa(c.soldeMobileMoney + c.soldeCarteBancaire)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* FACTURE EXCEL */}
          {onglet === "facture" && (
            <TableauExcel
              proprietaire={reglages.nom}
              whatsapp={reglages.whatsapp}
              ville={reglages.ville}
              logoUrl={reglages.logoUrl}
            />
          )}

          {/* PRODUITS */}
          {onglet === "produits" && (
            <div className="rounded-[2rem] border border-terre bg-white p-6 sm:p-9">
              <h2 className="font-display text-3xl font-black text-encre">Mes produits</h2>
              <p className="mt-2 text-encre/65">
                Changez vos prix et vos quantités : la boutique publique se met à jour.
              </p>
              <div className="mt-8 overflow-x-auto">
                <table className="w-full min-w-[46rem] text-left">
                  <thead>
                    <tr className="border-b-2 border-encre/80">
                      <th className="label-marche py-3 text-encre/60">Produit</th>
                      <th className="label-marche py-3 text-encre/60">Catégorie</th>
                      <th className="label-marche py-3 text-encre/60">Unité</th>
                      <th className="label-marche py-3 text-encre/60">Prix unitaire</th>
                      <th className="label-marche py-3 text-encre/60">Quantité</th>
                      <th className="label-marche py-3 text-encre/60">Disponible</th>
                    </tr>
                  </thead>
                  <tbody>
                    {produits.map((p) => (
                      <tr key={p.id} className="border-b border-terre">
                        <td className="py-3 font-semibold text-encre">{p.nom}</td>
                        <td className="py-3 text-encre/70">{p.categorie}</td>
                        <td className="py-3 text-encre/70">{p.unite}</td>
                        <td className="py-3">
                          <input
                            type="number"
                            value={p.prixUnitaire}
                            onChange={(e) =>
                              majProduit(p.id, { prixUnitaire: Math.max(0, Number(e.target.value) || 0) })
                            }
                            className="tabulaire w-36 rounded-lg border border-terre px-3 py-2 text-ocre outline-none focus:border-foret"
                          />
                        </td>
                        <td className="py-3">
                          <input
                            type="number"
                            value={p.quantite}
                            onChange={(e) =>
                              majProduit(p.id, { quantite: Math.max(0, Number(e.target.value) || 0) })
                            }
                            className="tabulaire w-28 rounded-lg border border-terre px-3 py-2 outline-none focus:border-foret"
                          />
                        </td>
                        <td className="py-3">
                          <button
                            type="button"
                            onClick={() => majProduit(p.id, { disponible: !p.disponible })}
                            className={`rounded-full px-4 py-1.5 text-xs font-semibold ${
                              p.disponible ? "bg-[#eef6f0] text-foret" : "bg-[#fdecea] text-[#9b2c1c]"
                            }`}
                          >
                            {p.disponible ? "En vente" : "Retiré"}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* IA */}
          {onglet === "ia" && (
            <div className="rounded-[2rem] border border-terre bg-white p-6 sm:p-9">
              <h2 className="font-display text-3xl font-black text-encre">Messages de l&apos;IA</h2>
              <p className="mt-2 text-encre/65">
                Ce que les visiteurs demandent à l&apos;IA SBS — gratuit pour tous, enregistré ici
                pour vous.
              </p>
              <ul className="mt-8 space-y-4">
                {conversationsInitiales.length === 0 && (
                  <li className="rounded-2xl border border-terre bg-voile px-5 py-8 text-center text-encre/50">
                    Aucune question pour l&apos;instant.
                  </li>
                )}
                {conversationsInitiales.map((c) => (
                  <li key={c.id} className="rounded-2xl border border-terre p-5">
                    <p className="label-marche text-encre/45">
                      {new Date(c.date).toLocaleString("fr-FR")} — question
                    </p>
                    <p className="mt-2 text-lg font-semibold text-encre">{c.question}</p>
                    <p className="mt-3 border-l-4 border-foret pl-4 text-encre/75">{c.reponse}</p>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
