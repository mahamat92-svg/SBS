import type { Metadata } from "next";
import { db } from "@/db";
import { sbsClients, sbsFactures, sbsIaConversations, sbsPaiements, sbsSettings, sbsProduits } from "@/db/schema";
import { lireReglages } from "@/lib/seed";
import { desc, sql } from "drizzle-orm";
import AdminClient from "./AdminClient";

export const metadata: Metadata = {
  title: "Dashboard Admin — SBS",
  description: "Tableau de bord du propriétaire SBS : solde, clients, factures, produits et réglages.",
};

export default async function PageAdmin() {
  let reglages;
  let paiements: (typeof sbsPaiements.$inferSelect)[] = [];
  let clients: (typeof sbsClients.$inferSelect)[] = [];
  let factures: (typeof sbsFactures.$inferSelect)[] = [];
  let conversations: (typeof sbsIaConversations.$inferSelect)[] = [];
  let produits: (typeof sbsProduits.$inferSelect)[] = [];
  let totalEncaisse = 0;

  try {
    reglages = await lireReglages();
    paiements = await db.select().from(sbsPaiements).orderBy(desc(sbsPaiements.date)).limit(20);
    clients = await db.select().from(sbsClients).orderBy(desc(sbsClients.date)).limit(100);
    factures = await db.select().from(sbsFactures).orderBy(desc(sbsFactures.date)).limit(20);
    conversations = await db.select().from(sbsIaConversations).orderBy(desc(sbsIaConversations.date)).limit(20);
    produits = await db.select().from(sbsProduits).orderBy(sbsProduits.ordre);
    const [t] = await db.select({ n: sql<number>`coalesce(sum(${sbsPaiements.montant}),0)` }).from(sbsPaiements);
    totalEncaisse = Number(t?.n ?? 0);
  } catch {
    // base non prête : le dashboard affiche des valeurs vides
  }

  return (
    <AdminClient
      reglages={
        reglages ?? {
          id: "principal",
          nom: "SBS — Héritage Agricole et Naturel",
          slogan: "Héritage Agricole et Naturel",
          proprietaire: "M. Abakar Ngarnia",
          logoUrl: "/images/logo-sbs.svg",
          whatsapp: "+235 66 00 00 00",
          email: "contact@sbs-agriculture.cm",
          ville: "Ngaoundéré",
          pays: "Cameroun",
          orangeMoney: "+235 __ __ __ __",
          mtnMomo: "+235 __ __ __ __",
          wave: "+235 __ __ __ __",
          carteBancaire: "Visa / Mastercard **** ____",
          nomBanque: "Afriland First Bank",
          soldeMobileMoney: 0,
          soldeCarteBancaire: 0,
          soldeEspeces: 0,
          updatedAt: new Date(),
        }
      }
      paiementsInitiaux={paiements}
      clientsInitiaux={clients}
      facturesInitiales={factures}
      conversationsInitiales={conversations}
      produitsInitiaux={produits}
      totalEncaisse={totalEncaisse}
    />
  );
}
