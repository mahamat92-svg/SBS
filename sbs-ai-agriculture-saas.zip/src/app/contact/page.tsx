"use client";

import { useState } from "react";
import type { ReactNode } from "react";
import { MessageCircle, Send, MapPin, Clock } from "lucide-react";
import { IconeFacebook } from "@/components/IconeFacebook";

type Carte = {
  cle: string;
  icone: ReactNode;
  titre: string;
  texte: string;
  sous: string;
  couleur: string;
  lien?: string;
};

export default function Contact() {
  const [form, setForm] = useState({ nom: "", telephone: "", sujet: "Achat de produits", message: "" });
  const numero = "23566000000";

  const lien =
    `https://wa.me/${numero}?text=` +
    encodeURIComponent(
      `Bonjour, je suis ${form.nom || "un client"} (${form.telephone || "sans numéro"}). Sujet : ${form.sujet}. ${form.message}`,
    );

  const cartes: Carte[] = [
    {
      cle: "whatsapp",
      icone: <MessageCircle className="h-6 w-6" />,
      titre: "WhatsApp du propriétaire",
      texte: "+235 66 00 00 00",
      sous: "Le plus rapide — réponse dans la journée",
      couleur: "text-[#25D366]",
      lien: `https://wa.me/${numero}`,
    },
    {
      cle: "facebook",
      icone: <IconeFacebook className="h-6 w-6" />,
      titre: "Page Facebook SBS",
      texte: "facebook.com/sbs-heritage",
      sous: "Photos des récoltes et des animaux disponibles",
      couleur: "text-[#1877F2]",
      lien: "https://facebook.com",
    },
    {
      cle: "bureau",
      icone: <MapPin className="h-6 w-6" />,
      titre: "Bureau SBS",
      texte: "Ngaoundéré, Cameroun",
      sous: "Ouvert du lundi au samedi, de 8 h à 18 h",
      couleur: "text-foret",
    },
    {
      cle: "ia",
      icone: <Clock className="h-6 w-6" />,
      titre: "IA SBS gratuite",
      texte: "24 h sur 24, 7 jours sur 7",
      sous: "Cliquez sur « Parler à l'IA » en bas à droite",
      couleur: "text-ocre",
    },
  ];

  return (
    <>
      <section className="relative isolate overflow-hidden">
        <div className="absolute inset-0 -z-10">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="images/hero-champ.jpg" alt="" className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-nuit/95 via-nuit/78 to-foret/55" />
        </div>
        <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
          <p className="label-marche text-mangue">Contact</p>
          <h1 className="mt-6 max-w-3xl font-display text-[clamp(2.6rem,7vw,5.4rem)] font-black leading-[0.95] text-white">
            Un message, et le propriétaire vous répond.
          </h1>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-[1fr_1.1fr]">
          <div className="space-y-5">
            {cartes.map((c) => (
              <div key={c.cle} className="flex items-start gap-5 rounded-3xl border border-terre bg-white p-6">
                <span className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-voile ${c.couleur}`}>
                  {c.icone}
                </span>
                <div>
                  <p className="label-marche text-encre/50">{c.titre}</p>
                  {c.lien ? (
                    <a
                      href={c.lien}
                      target="_blank"
                      rel="noreferrer"
                      className="tabulaire mt-1.5 block font-display text-2xl font-black text-encre lien-souligne"
                    >
                      {c.texte}
                    </a>
                  ) : (
                    <p className="tabulaire mt-1.5 font-display text-2xl font-black text-encre">{c.texte}</p>
                  )}
                  <p className="mt-1 text-encre/60">{c.sous}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="rounded-[2rem] border border-terre bg-white p-8 sm:p-10">
            <p className="label-marche text-foret">Écrire au propriétaire</p>
            <h2 className="mt-4 font-display text-3xl font-black text-encre">Votre message</h2>
            <p className="mt-3 text-encre/65">
              Remplissez ce formulaire : votre message s&apos;ouvre directement dans WhatsApp, prêt à
              être envoyé.
            </p>

            <div className="mt-7 space-y-4">
              <input
                placeholder="Votre nom complet"
                value={form.nom}
                onChange={(e) => setForm({ ...form, nom: e.target.value })}
                className="w-full rounded-xl border border-terre px-4 py-3.5 outline-none focus:border-foret"
              />
              <input
                placeholder="Votre numéro de téléphone"
                value={form.telephone}
                onChange={(e) => setForm({ ...form, telephone: e.target.value })}
                className="tabulaire w-full rounded-xl border border-terre px-4 py-3.5 outline-none focus:border-foret"
              />
              <select
                value={form.sujet}
                onChange={(e) => setForm({ ...form, sujet: e.target.value })}
                className="w-full rounded-xl border border-terre px-4 py-3.5 outline-none focus:border-foret"
              >
                <option>Achat de produits</option>
                <option>Abonnement Pro ou Business</option>
                <option>Question sur un outil IA</option>
                <option>Livraison</option>
                <option>Autre</option>
              </select>
              <textarea
                rows={5}
                placeholder="Votre message…"
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                className="w-full resize-none rounded-xl border border-terre px-4 py-3.5 outline-none focus:border-foret"
              />
            </div>

            <a
              href={lien}
              target="_blank"
              rel="noreferrer"
              className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-[#25D366] px-6 py-4 text-sm font-semibold text-[#07321b] transition-transform hover:-translate-y-0.5"
            >
              <Send className="h-4 w-4" /> Envoyer sur WhatsApp
            </a>

            <div className="mt-6 flex items-center gap-3 rounded-2xl bg-voile px-5 py-4">
              <IconeFacebook className="h-6 w-6 shrink-0 text-[#1877F2]" />
              <p className="text-sm text-encre/70">
                Vous pouvez aussi laisser votre lien Facebook : le propriétaire l&apos;ajoute à votre
                fiche client pour vous retrouver plus vite.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
