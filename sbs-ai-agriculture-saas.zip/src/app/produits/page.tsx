import type { Metadata } from "next";
import { db } from "@/db";
import { sbsProduits, sbsSettings } from "@/db/schema";
import { lireReglages } from "@/lib/seed";
import { fcfa } from "@/lib/data";
import { MessageCircle, ShoppingCart, Truck, Wallet } from "lucide-react";

export const metadata: Metadata = {
  title: "Produits — SBS | Céréales, légumes, vaches, chèvres, poulets",
  description:
    "La boutique du propriétaire SBS : maïs, mil, arachide, tomate, manioc, oignon, vaches, chèvres, moutons, poulets et poules pondeuses. Commande par WhatsApp.",
};

export default async function PageProduits() {
  let produits: (typeof sbsProduits.$inferSelect)[] = [];
  let whatsapp = "+235 66 00 00 00";
  let proprietaire = "le propriétaire de SBS";
  try {
    produits = await db.select().from(sbsProduits).orderBy(sbsProduits.ordre);
    const r = await lireReglages();
    if (r) {
      whatsapp = r.whatsapp;
      proprietaire = r.proprietaire;
    }
  } catch {
    // catalogue vide : la page reste lisible
  }

  const numero = whatsapp.replace(/[^\d]/g, "");
  const agriculture = produits.filter((p) => p.categorie === "Agriculture");
  const elevage = produits.filter((p) => p.categorie === "Élevage");

  const lienCommande = (nom: string, prix: number) =>
    `https://wa.me/${numero}?text=` +
    encodeURIComponent(`Bonjour ${proprietaire}, je suis intéressé par : ${nom} à ${fcfa(prix)}.`);

  return (
    <>
      <section className="relative isolate overflow-hidden">
        <div className="absolute inset-0 -z-10">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="images/produits-marche.jpg" alt="" className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-nuit/94 via-nuit/72 to-nuit/30" />
        </div>
        <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
          <p className="label-marche text-mangue">Boutique SBS</p>
          <h1 className="mt-6 max-w-3xl font-display text-[clamp(2.6rem,7vw,5.4rem)] font-black leading-[0.95] text-white">
            Les produits du propriétaire, vendus par le propriétaire.
          </h1>
          <p className="mt-7 max-w-xl text-lg leading-relaxed text-white/80">
            Vous commandez sur WhatsApp, vous payez par Orange Money, MTN MoMo, Wave, Carte Bancaire
            ou Espèces. La livraison se prépare le jour même.
          </p>
        </div>
      </section>

      {[
        { titre: "Agriculture", liste: agriculture, image: "images/hero-champ.jpg" },
        { titre: "Élevage", liste: elevage, image: "images/elevage-zebu.jpg" },
      ].map((bloc) => (
        <section key={bloc.titre} className="mx-auto max-w-7xl px-4 pt-16 sm:px-6 lg:px-8">
          <div className="flex items-center gap-5">
            <h2 className="font-display text-4xl font-black text-encre">{bloc.titre}</h2>
            <span className="h-px flex-1 bg-terre" />
            <span className="tabulaire label-marche text-encre/50">{bloc.liste.length} produits</span>
          </div>

          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {bloc.liste.map((p) => (
              <article
                key={p.id}
                className="group flex flex-col overflow-hidden rounded-3xl border border-terre bg-white transition-shadow hover:shadow-[0_35px_70px_-40px_rgba(11,59,34,0.65)]"
              >
                <div className="relative h-44 overflow-hidden">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={bloc.image}
                    alt={p.nom}
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-nuit/75 to-transparent" />
                  <p className="absolute bottom-4 left-5 font-display text-2xl font-black text-white">
                    {p.nom}
                  </p>
                  <p className="absolute right-4 top-4 rounded-full bg-white/95 px-3 py-1.5 text-xs font-semibold text-foret">
                    {p.unite}
                  </p>
                </div>
                <div className="flex flex-1 flex-col p-6">
                  <p className="tabulaire font-display text-3xl font-black text-ocre">{fcfa(p.prixUnitaire)}</p>
                  <p className="mt-3 flex-1 text-[0.94rem] leading-relaxed text-encre/70">{p.description}</p>
                  <p className="mt-4 text-sm text-encre/55">
                    Stock disponible :{" "}
                    <span className="tabulaire font-semibold text-encre/80">{p.quantite}</span>
                  </p>
                  <a
                    href={lienCommande(p.nom, p.prixUnitaire)}
                    target="_blank"
                    rel="noreferrer"
                    className="mt-5 inline-flex items-center justify-center gap-2 rounded-full bg-foret px-5 py-3.5 text-sm font-semibold text-white transition-transform hover:-translate-y-0.5"
                  >
                    <ShoppingCart className="h-4 w-4" /> Commander sur WhatsApp
                  </a>
                </div>
              </article>
            ))}
          </div>
        </section>
      ))}

      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="grid gap-6 sm:grid-cols-3">
          {[
            { Icone: Truck, titre: "Livraison", texte: "Livraison dans votre village sur simple message WhatsApp." },
            { Icone: Wallet, titre: "Paiement", texte: "Orange Money, MTN MoMo, Wave, Carte Bancaire ou Espèces à la livraison." },
            { Icone: MessageCircle, titre: "Conseil", texte: "Une question sur un produit ? L'IA SBS répond gratuitement, tout de suite." },
          ].map((x) => (
            <div key={x.titre} className="rounded-3xl border border-terre bg-white p-7">
              <x.Icone className="h-7 w-7 text-foret" />
              <h3 className="mt-5 font-display text-2xl font-black text-encre">{x.titre}</h3>
              <p className="mt-2 text-encre/65">{x.texte}</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
