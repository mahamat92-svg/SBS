import type { Metadata } from "next";
import Outils from "@/components/Outils";
import { CULTURES, fcfa } from "@/lib/data";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

export const metadata: Metadata = {
  title: "Agriculture — SBS | Maïs, Mil, Arachide, Tomate, Manioc, Oignon",
  description:
    "Météo de mon champ, Docteur Plante, Conseil IA, Ma Récolte, Quand Arroser, Mon Score Agricole : les 6 outils IA du SBS pour les agriculteurs du Cameroun et du Tchad.",
};

export default function PageAgriculture() {
  return (
    <>
      <section className="relative isolate overflow-hidden">
        <div className="absolute inset-0 -z-10">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="images/produits-marche.jpg"
            alt=""
            className="h-full w-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-foret/95 via-foret/80 to-nuit/70" />
        </div>
        <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
          <p className="label-marche text-mangue">Service 01 — Agriculture</p>
          <h1 className="mt-6 max-w-4xl font-display text-[clamp(2.6rem,7vw,5.6rem)] font-black leading-[0.95] text-white">
            Six cultures, six outils IA, une seule question : <em className="not-italic text-mangue">que faire aujourd&apos;hui ?</em>
          </h1>
          <div className="mt-10 flex flex-wrap gap-2">
            {CULTURES.map((c) => (
              <span key={c.id} className="rounded-full border border-white/25 px-4 py-2 text-sm text-white/85">
                {c.nom} · <span className="tabulaire">{fcfa(c.prixSac)}</span> / sac
              </span>
            ))}
          </div>
        </div>
      </section>

      <div className="pt-16">
        <Outils service="Agriculture" />
      </div>

      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="rounded-[2rem] border border-terre bg-white p-8 sm:p-12">
          <p className="label-marche text-foret">Rendements & prix du marché</p>
          <h2 className="mt-4 font-display text-3xl font-black text-encre sm:text-4xl">
            Ce que vaut vraiment votre champ
          </h2>
          <div className="mt-8 overflow-x-auto">
            <table className="w-full min-w-[42rem] text-left">
              <thead>
                <tr className="border-b-2 border-encre/80">
                  <th className="label-marche py-3 text-encre/60">Culture</th>
                  <th className="label-marche py-3 text-encre/60">Rendement</th>
                  <th className="label-marche py-3 text-encre/60">Prix du sac</th>
                  <th className="label-marche py-3 text-encre/60">Cycle</th>
                  <th className="label-marche py-3 text-encre/60">Semis</th>
                  <th className="label-marche py-3 text-encre/60">Arrosage</th>
                </tr>
              </thead>
              <tbody>
                {CULTURES.map((c) => (
                  <tr key={c.id} className="border-b border-terre">
                    <td className="py-4 font-semibold text-encre">{c.nom}</td>
                    <td className="tabulaire py-4 text-encre/75">{c.rendementSacsHa} sacs / ha</td>
                    <td className="tabulaire py-4 font-semibold text-ocre">{fcfa(c.prixSac)}</td>
                    <td className="tabulaire py-4 text-encre/75">{c.cycleJours} jours</td>
                    <td className="py-4 text-encre/75">{c.semis}</td>
                    <td className="tabulaire py-4 text-encre/75">tous les {c.arrosageJours} jours</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Link
            href="/produits"
            className="mt-8 inline-flex items-center gap-2 rounded-full bg-foret px-6 py-3.5 text-sm font-semibold text-white transition-transform hover:-translate-y-0.5"
          >
            Acheter mes récoltes <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </>
  );
}
