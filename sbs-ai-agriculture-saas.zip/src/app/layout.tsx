import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Fraunces, Outfit } from "next/font/google";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import FloatingActions from "@/components/FloatingActions";
import { lireReglages } from "@/lib/seed";
import "./globals.css";

export const dynamic = "force-dynamic";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  weight: ["400", "700", "900"],
  display: "swap",
});

const outfit = Outfit({
  subsets: ["latin"],
  variable: "--font-outfit",
  weight: ["300", "400", "500", "600", "700"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "SBS — Héritage Agricole et Naturel | Agriculture & Élevage",
  description:
    "SBS est le logiciel personnel d'un agriculteur-éleveur : météo de mon champ, docteur plante et animal, calcul de récolte, score agricole, boutique de céréales et d'animaux. Payable par Orange Money, MTN MoMo, Wave et Carte Bancaire.",
  keywords: [
    "SBS",
    "agriculture Cameroun",
    "élevage Tchad",
    "maïs",
    "mil",
    "arachide",
    "vaches",
    "météo champ",
    "FCFA",
  ],
};

const DEFAUT = {
  nom: "SBS — Héritage Agricole et Naturel",
  slogan: "Héritage Agricole et Naturel",
  proprietaire: "M. Abakar Ngarnia",
  whatsapp: "+235 66 00 00 00",
  email: "contact@sbs-agriculture.cm",
  ville: "Ngaoundéré",
  pays: "Cameroun",
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  let reglages = DEFAUT;
  try {
    const r = await lireReglages();
    if (r) {
      reglages = {
        nom: r.nom,
        slogan: r.slogan,
        proprietaire: r.proprietaire,
        whatsapp: r.whatsapp,
        email: r.email,
        ville: r.ville,
        pays: r.pays,
      };
    }
  } catch {
    // La base n'est pas encore prête : on garde les valeurs par défaut.
  }

  return (
    <html lang="fr" className={`${fraunces.variable} ${outfit.variable}`}>
      <body className="min-h-screen bg-papier text-encre antialiased">
        <Nav nom={reglages.nom} whatsapp={reglages.whatsapp} />
        <main>{children}</main>
        <Footer
          nom={reglages.nom}
          whatsapp={reglages.whatsapp}
          proprietaire={reglages.proprietaire}
          ville={reglages.ville}
          pays={reglages.pays}
          email={reglages.email}
        />
        <FloatingActions whatsapp={reglages.whatsapp} proprietaire={reglages.proprietaire} />
      </body>
    </html>
  );
}
